--
-- Datenbank: `gate_50`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `anisettings`
--

CREATE TABLE `anisettings` (
  `id` int(255) NOT NULL,
  `chev_num` varchar(200) NOT NULL,
  `pos` varchar(200) NOT NULL,
  `glyph_num` varchar(200) NOT NULL,
  `glyph_tex` varchar(200) NOT NULL,
  `version` varchar(2000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `anisettings`
--

INSERT INTO `anisettings` (`id`, `chev_num`, `pos`, `glyph_num`, `glyph_tex`, `version`) VALUES
(1, '1', '<0.90630, 0.42263, -0.00108, 0.00000>', 'empty', 'empty', 'empty'),
(4, '3', '<0.96592, -0.25886, -0.00036, 0.00000>', 'empty', 'empty', 'empty'),
(3, '2', '<0.99620, 0.08714, -0.00034, 0.00000>', 'empty', 'empty', 'empty'),
(5, '4', '<-0.25033, 0.96816, 0.00016, 0.00134>', 'empty', 'empty', 'empty'),
(6, '5', '<0.08718, 0.99619, -0.00043, 0.00115>', 'empty', 'empty', 'empty'),
(7, '6', '<0.42264, 0.90630, -0.00093, 0.00073>', 'empty', 'empty', 'empty'),
(8, '7', '<-0.82412, 0.56641, 0.00089, 0.00073>', 'empty', 'empty', 'empty'),
(9, '8', '<-0.57358, 0.81915, 0.00051, 0.00077>', 'empty', 'empty', 'empty'),
(10, 'enpty', 'empty', '1', 'a7939aa1-c6ac-588e-34c1-fadc70daea09', 'empty'),
(11, 'enpty', 'empty', '2', '19232a95-e076-39e1-a432-6c073ac23dad', 'empty'),
(12, 'enpty', 'empty', '3', 'c79a30d2-16a1-857d-593f-14ec24ffd2a1', 'empty'),
(13, 'enpty', 'empty', '4', '964bed7b-b227-5629-83be-f492cb9c321c', 'empty'),
(14, 'enpty', 'empty', '5', 'e24602cd-0fba-26b0-25a0-a43c94a6b308', 'empty'),
(15, 'enpty', 'empty', '6', '828f0368-f878-68f8-05de-5dfbac2c3d79', 'empty'),
(16, 'enpty', 'empty', '7', '0e9c7530-3f34-c23b-7eb2-a4ae11d0c18b', 'empty'),
(17, 'enpty', 'empty', '8', '1e1eb195-9524-fc78-2226-eeb671871288', 'empty'),
(18, 'enpty', 'empty', '9', 'c2b2ba65-02cd-a3be-6a39-ff7af204cbb0', 'empty'),
(19, 'enpty', 'empty', '10', 'b5c6b547-e9b8-2e44-c65f-d6490dd49505', 'empty'),
(20, 'enpty', 'empty', '11', '79804ec1-2e81-c811-94cb-3221ff667163', 'empty'),
(21, 'enpty', 'empty', '12', 'e2a439dc-18d7-6530-2df5-2665af6b4ca0', 'empty'),
(22, 'enpty', 'empty', '13', '3d3f8a52-d8ab-4fad-b5cd-1b6584d4288c', 'empty'),
(23, 'enpty', 'empty', '14', '593c432e-b383-e54c-644e-59343fb7c01c', 'empty'),
(24, 'enpty', 'empty', '15', 'e82dda29-e7af-e774-ebaf-5049b2b1b7b5', 'empty'),
(25, 'enpty', 'empty', '16', '8327c3fb-2272-189f-5356-ff44f6090bd7', 'empty'),
(26, 'enpty', 'empty', '17', '4543e1ef-540d-9d3a-246b-0198a206c49f', 'empty'),
(27, 'enpty', 'empty', '18', 'dd837261-8352-fe6a-47af-28026437419a', 'empty'),
(28, 'enpty', 'empty', '19', '26344372-c5a9-87d3-4692-9585b7158d77', 'empty'),
(29, 'enpty', 'empty', '20', '1489f502-28a8-66fc-fdce-2bed102bae50', 'empty'),
(30, 'enpty', 'empty', '21', '51da2032-411a-63df-bd07-3a8d52707434', 'empty'),
(31, 'enpty', 'empty', '22', 'd3c2b0cd-786a-8a0f-c209-493993bc5cf6', 'empty'),
(32, 'enpty', 'empty', '23', 'e56b9111-0d43-b6a1-95a8-6c8e8a9ccbc6', 'empty'),
(33, 'enpty', 'empty', '24', '223846fd-8adf-a68a-4c4a-91ff7b671273', 'empty'),
(34, 'enpty', 'empty', '25', 'd9b41e02-be7f-47cf-085b-b62401012b93', 'empty'),
(35, 'enpty', 'empty', '26', '7f73889a-7ae7-5997-9210-7f3eb5f819a2', 'empty'),
(36, 'enpty', 'empty', '27', '2941d9ec-0b75-fadc-0651-aad16923511e', 'empty'),
(37, 'enpty', 'empty', '28', '0308d96f-3b80-b68d-0106-2d78c9328385', 'empty'),
(38, 'enpty', 'empty', '29', '37e1b3fb-07a5-d7c9-56d7-c71a5b6f3f3d', 'empty'),
(39, 'enpty', 'empty', '30', 'dce19da3-bfc2-f062-c79a-6fcc950f48d5', 'empty'),
(40, 'enpty', 'empty', '31', '8819c25d-4458-66b4-8396-f4b90204d45c', 'empty'),
(41, 'enpty', 'empty', '32', 'b293f766-36d0-e3ff-141d-01c97408bab0', 'empty'),
(42, 'enpty', 'empty', '33', 'fefdad1a-69f6-2c6f-9ae6-6435fd8748a6', 'empty'),
(43, 'enpty', 'empty', '34', '9d324b06-0c53-cf94-707a-4e42da815fbb', 'empty'),
(44, 'enpty', 'empty', '35', 'd156c145-6b45-890b-6351-746337fbb638', 'empty'),
(45, 'enpty', 'empty', '36', '8709f2d6-c7e1-405c-a218-bdcdce2e3a4b', 'empty'),
(46, '0', '<-0.70711, -0.70711, 0.00018, 0.00000>', 'empty', 'empty', 'empty'),
(47, 'enpty', 'empty', '0', '8dcd4a48-2d37-4909-9f78-f7a9eb4ef903', 'empty'),
(50, 'empty', 'empty', 'empty', 'empty', 'v.5.1.1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `api_key`
--

CREATE TABLE `api_key` (
  `id` int(255) NOT NULL,
  `datas` varchar(200) NOT NULL,
  `owner` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `api_key`
--

INSERT INTO `api_key` (`id`, `datas`, `owner`) VALUES
(1, 'd88bc12d-b3c7d631-3c6b7351-62c366b2', 'cyber Ahn');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `backup`
--

CREATE TABLE `backup` (
  `id` int(255) NOT NULL DEFAULT '0',
  `name` varchar(200) NOT NULL,
  `randial` varchar(200) NOT NULL,
  `sim` varchar(200) NOT NULL,
  `kordi` varchar(150) NOT NULL,
  `owner` varchar(150) NOT NULL,
  `datas` varchar(1000) NOT NULL,
  `channel` varchar(150) NOT NULL,
  `gatestatus` varchar(500) NOT NULL,
  `imagesurl` varchar(2000) NOT NULL,
  `model` varchar(2000) NOT NULL,
  `ausf` varchar(2000) NOT NULL,
  `prob` varchar(2000) NOT NULL,
  `radkanal` varchar(2000) NOT NULL,
  `rpsim` varchar(2000) NOT NULL,
  `smail` varchar(2000) NOT NULL,
  `rati` int(200) NOT NULL,
  `displowner` varchar(2000) NOT NULL,
  `products` varchar(2000) NOT NULL,
  `nwid` varchar(200) NOT NULL,
  `gateage` varchar(200) NOT NULL,
  `pingc` int(200) NOT NULL,
  `opent` int(200) NOT NULL,
  `blacklist` varchar(200) NOT NULL,
  `imageowner` varchar(200) NOT NULL,
  `iristype` varchar(200) NOT NULL,
  `simrati` varchar(200) CHARACTER SET utf16 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `backup`
--

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `bann`
--

CREATE TABLE `bann` (
  `id` int(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `reason` varchar(2000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `bann`
--

INSERT INTO `bann` (`id`, `name`, `reason`) VALUES
(21, 'Han Halsey', 'Spam'),
(16, 'aditi', 'Beta Server'),
(13, 'jamiebanker Resident', 'Bot'),
(27, 'Sandbox OA', 'sandbox spam');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `contacts`
--

CREATE TABLE `contacts` (
  `id` int(255) NOT NULL,
  `namefrom` varchar(200) NOT NULL,
  `nameto` varchar(200) NOT NULL,
  `timstart` varchar(200) NOT NULL,
  `timend` varchar(2000) NOT NULL,
  `data` varchar(2000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `contacts`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `gates`
--

CREATE TABLE `gates` (
  `id` int(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `randial` varchar(200) NOT NULL,
  `sim` varchar(200) NOT NULL,
  `kordi` varchar(150) NOT NULL,
  `owner` varchar(150) NOT NULL,
  `datas` varchar(1000) NOT NULL,
  `channel` varchar(150) NOT NULL,
  `gatestatus` varchar(500) NOT NULL,
  `imagesurl` varchar(2000) NOT NULL,
  `model` varchar(2000) NOT NULL,
  `ausf` varchar(2000) NOT NULL,
  `prob` varchar(2000) NOT NULL,
  `radkanal` varchar(2000) NOT NULL,
  `rpsim` varchar(2000) NOT NULL,
  `smail` varchar(2000) NOT NULL,
  `rati` int(200) NOT NULL,
  `displowner` varchar(2000) NOT NULL,
  `products` varchar(2000) NOT NULL,
  `nwid` varchar(200) NOT NULL,
  `gateage` varchar(200) NOT NULL,
  `pingc` int(200) NOT NULL,
  `opent` int(200) NOT NULL,
  `blacklist` varchar(200) NOT NULL,
  `imageowner` varchar(200) NOT NULL,
  `iristype` varchar(200) NOT NULL,
  `simrati` varchar(200) CHARACTER SET utf16 NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `gates`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `media_hud`
--

CREATE TABLE `media_hud` (
  `id` int(255) NOT NULL,
  `obkey` varchar(200) NOT NULL,
  `owner` varchar(200) NOT NULL,
  `favo` varchar(200) NOT NULL,
  `data` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `media_hud`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `opengate`
--

CREATE TABLE `opengate` (
  `id` int(255) NOT NULL,
  `owner` varchar(200) NOT NULL,
  `sim` varchar(200) NOT NULL,
  `kanal` varchar(200) NOT NULL,
  `posi` varchar(200) NOT NULL,
  `status` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `opengate`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `product`
--

CREATE TABLE `product` (
  `id` int(255) NOT NULL,
  `name` varchar(200) NOT NULL,
  `vers` varchar(200) NOT NULL,
  `kana` varchar(150) NOT NULL,
  `pass` varchar(150) NOT NULL,
  `dring` varchar(300) NOT NULL,
  `obkey` varchar(300) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `product`
--



-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `rec_stat`
--

CREATE TABLE `rec_stat` (
  `id` int(255) NOT NULL,
  `user` varchar(200) NOT NULL,
  `gate` varchar(200) NOT NULL,
  `tim` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `rec_stat`
--



-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `settings`
--

CREATE TABLE `settings` (
  `id` int(255) NOT NULL,
  `gatetyp` varchar(200) NOT NULL,
  `sound` varchar(200) NOT NULL,
  `color` varchar(200) NOT NULL,
  `channel` varchar(200) NOT NULL,
  `typos` varchar(200) NOT NULL,
  `close` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `settings`
--

INSERT INTO `settings` (`id`, `gatetyp`, `sound`, `color`, `channel`, `typos`, `close`) VALUES
(1, 'Milkyway', 'eb81f863-3bf4-5888-9f96-9c0b14f2aaf6', '<0.87451, 0.33333, 0.13333>', '-904000,-905000', '1', '72633c45-b610-7356-dce5-b122931a78c9'),
(2, 'Pegasus', '14426bda-3af4-b5ae-284b-7b1a46a9e786', '<0.23529, 0.61961, 1.00000>', '-804000,-805000', '2', '72633c45-b610-7356-dce5-b122931a78c9'),
(3, 'Tula', 'e4069025-6bc3-e121-ccb9-02a75ebf644c', '<0.23529, 0.61961, 1.00000>', '-804000,-805000', '2', '72633c45-b610-7356-dce5-b122931a78c9'),
(4, 'Tollan', 'b6a8ddef-08be-2483-acd9-86aeefd5791d', '<0.23529, 0.61961, 1.00000>', '-904000,-905000', '1', '72633c45-b610-7356-dce5-b122931a78c9'),
(5, 'Low Prim', 'b6a8ddef-08be-2483-acd9-86aeefd5791d', '<1.00000, 1.00000, 1.00000>', '-804000,-805000', '2', '72633c45-b610-7356-dce5-b122931a78c9'),
(6, 'Iconian', 'e4069025-6bc3-e121-ccb9-02a75ebf644c', '<1.00000, 1.00000, 1.00000>', '-504000,-505000', '4', 'e316a057-896a-7ab5-2037-364ec030449f'),
(7, 'Universe', '01aadb1a-f374-8149-b7fb-caa11207157f', '<1.00000, 1.00000, 1.00000>', '-604000,-605000', '3', 'f564e34b-5e8c-0462-2043-e52e8508b1c1');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tgnrp`
--

CREATE TABLE `tgnrp` (
  `id` int(255) NOT NULL,
  `owner` varchar(200) NOT NULL,
  `data` varchar(200) NOT NULL,
  `image` varchar(2000) NOT NULL,
  `dname` varchar(2000) NOT NULL,
  `favo` varchar(2000) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tgnrp`
--


-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `unisettings`
--

CREATE TABLE `unisettings` (
  `id` int(255) NOT NULL,
  `chev_num` varchar(200) NOT NULL,
  `pos` varchar(200) NOT NULL,
  `glyph_tex` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `unisettings`
--

INSERT INTO `unisettings` (`id`, `chev_num`, `pos`, `glyph_tex`) VALUES
(1, '0', 'xyz', '9ee184af-2f60-2f96-e7dd-27f1facea67d'),
(2, '1', '<-0.08173, 0.00000, 0.00000, 0.99665>', '8af658c0-16e5-6c4d-29c0-73b196b4b30e'),
(3, '2', '<-0.14244, 0.00000, 0.00000, 0.98980>', '03c2e581-5106-64cc-8122-0cbe9fae49ba'),
(4, '3', '<-0.20261, 0.00000, 0.00000, 0.97926>', 'd6282d53-b950-4556-0c3f-8d8322c98dd3'),
(5, '4', '<-0.27044, 0.00000, 0.00000, 0.96274>', '96744b2e-811d-8658-d78b-42a324ab5a6b'),
(6, '5', '<-0.41775, 0.00000, 0.00000, 0.90856>', '3f6b30b8-8f7b-e26c-20a1-c740ba9316ae'),
(7, '6', '<-0.47244, 0.00000, 0.00000, 0.88136>', '1bfd10ef-23fa-d528-de40-cde81f1625a1'),
(8, '7', '<-0.52539, 0.00000, 0.00000, 0.85086>', '27c6706e-0193-a3e2-3968-bd25e57caa83'),
(9, '8', '<-0.57637, 0.00000, 0.00000, 0.81719>', '95dd742f-5cd8-b3b9-dc40-6b7ef32453c2'),
(10, '9', '<-0.69084, 0.00000, 0.00000, 0.72301>', 'a356957d-f457-9fb3-8b2a-9bcb2a4f6dac'),
(11, '10', '<-0.74545, 0.00000, 0.00000, 0.66656>', '9cf94480-9087-d69a-07db-d6d3810068d4'),
(12, '11', '<-0.78469, 0.00348, 0.00207, 0.61987>', '9c12ebb2-b950-bbe1-d52b-140ce6e91af1'),
(13, '12', '<-0.82107, 0.00358, 0.00184, 0.57081>', '3b67b7e1-b934-34b5-5e24-35fa47864873'),
(14, '13', '<-0.90404, 0.00381, 0.00120, 0.42744>', '7e8ba675-f3eb-b8ca-cea4-01edd7c1c101'),
(15, '14', '<-0.93479, 0.00388, 0.00087, 0.35517>', '5bb6896c-0aad-619e-1a6e-fe59cd7f7103'),
(16, '15', '<-0.95211, 0.00390, 0.00067, 0.30574>', '867f453a-a86b-75d3-6d00-4dd799274caf'),
(17, '16', '<-0.96901, 0.00428, 0.00086, 0.24700>', 'ff50981a-f96c-8dfb-2195-e2fb8a9ca7e8'),
(18, '17', '<-0.99572, 0.00434, 0.00016, 0.09237>', 'e0d351fd-8794-13a4-5f7b-fbf09aff05ca'),
(19, '18', '<-0.99973, 0.00432, -0.00016, 0.02267>', 'b4efa503-a5ea-f272-ca58-0b6d448ffb73'),
(20, '19', '<0.99955, -0.00427, 0.00039, 0.02969>', 'b12a9427-58b6-d52d-1d64-58cb33f5fa5e'),
(21, '20', '<0.99587, -0.00426, 0.00064, 0.09064>', '74fde30a-df11-45ba-bb6a-7b666006ef3a'),
(22, '21', '<0.96726, -0.00410, 0.00132, 0.25375>', 'c0e91124-59bf-3644-7284-0bdd95cb2f6b'),
(23, '22', '<0.94997, -0.00402, 0.00155, 0.31232>', '4624a105-be4b-4475-6f1e-9156a8857c52'),
(24, '23', '<0.92913, -0.00394, 0.00179, 0.36972>', '7c27cacc-3536-685e-815e-53f9edaec6c9'),
(25, '24', '<0.90108, -0.00382, 0.00203, 0.43363>', '0bd747c2-02a0-f93f-326e-0b6db72e610b'),
(26, '25', '<0.82709, -0.00349, 0.00254, 0.56205>', '067b6bb3-8604-c60c-cc61-f5bf0e21e456'),
(27, '26', '<0.78588, -0.00331, 0.00276, 0.61837>', '8064a1ee-dde9-3131-689d-43658d282482'),
(28, '27', '<0.75244, -0.00316, 0.00290, 0.65864>', '85754748-a777-1d36-c54f-c02e0b2d4a7c'),
(29, '28', '<0.70467, -0.00298, 0.00310, 0.70952>', 'b99242ea-c071-0d9e-8fd7-14db830edd7b'),
(30, '29', '<0.57790, -0.00245, 0.00355, 0.81610>', '18bac502-c2bf-7caa-f4c2-f1bb0d228c57'),
(31, '30', '<0.52700, -0.00224, 0.00367, 0.84986>', 'b72805a4-2fe1-c127-90ff-91af5ee91116'),
(32, '31', '<0.48178, -0.00205, 0.00376, 0.87628>', '2ba5d539-f094-818f-fd26-d04efde22df3'),
(33, '32', '<0.41154, -0.00176, 0.00389, 0.91138>', '7cab5ac2-79fc-d384-14a9-74d9c8681727'),
(34, '33', '<0.27229, -0.00120, 0.00408, 0.96220>', '23f3cf83-c514-1e2f-9c10-dd266a68549f'),
(35, '34', '<0.21302, -0.00095, 0.00414, 0.97704>', '7234ef24-21a8-3d3d-6e4c-c890c6eac9f9'),
(36, '35', '<0.14433, -0.00067, 0.00419, 0.98952>', '3698c703-5cbb-2e14-a54b-b2adcdf93388'),
(37, '36', '<0.07493, -0.00039, 0.00420, 0.99718>', '7143868d-8303-0d8a-9044-9468a124b5cc');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `user`
--

CREATE TABLE `user` (
  `id` int(255) NOT NULL,
  `avkey` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `pass` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `user`
--



--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `anisettings`
--
ALTER TABLE `anisettings`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `api_key`
--
ALTER TABLE `api_key`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `bann`
--
ALTER TABLE `bann`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `gates`
--
ALTER TABLE `gates`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `media_hud`
--
ALTER TABLE `media_hud`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `opengate`
--
ALTER TABLE `opengate`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `rec_stat`
--
ALTER TABLE `rec_stat`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tgnrp`
--
ALTER TABLE `tgnrp`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `unisettings`
--
ALTER TABLE `unisettings`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `anisettings`
--
ALTER TABLE `anisettings`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;
--
-- AUTO_INCREMENT für Tabelle `api_key`
--
ALTER TABLE `api_key`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT für Tabelle `bann`
--
ALTER TABLE `bann`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT für Tabelle `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66807;
--
-- AUTO_INCREMENT für Tabelle `gates`
--
ALTER TABLE `gates`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13189;
--
-- AUTO_INCREMENT für Tabelle `media_hud`
--
ALTER TABLE `media_hud`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
--
-- AUTO_INCREMENT für Tabelle `opengate`
--
ALTER TABLE `opengate`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;
--
-- AUTO_INCREMENT für Tabelle `product`
--
ALTER TABLE `product`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `rec_stat`
--
ALTER TABLE `rec_stat`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=756;
--
-- AUTO_INCREMENT für Tabelle `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT für Tabelle `tgnrp`
--
ALTER TABLE `tgnrp`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;
--
-- AUTO_INCREMENT für Tabelle `unisettings`
--
ALTER TABLE `unisettings`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
--
-- AUTO_INCREMENT für Tabelle `user`
--
ALTER TABLE `user`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3935;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

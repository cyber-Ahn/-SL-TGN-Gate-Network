<?php
include("../liberay/lib.php");
$version = " v.5.1.1";
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[version]!= "empty")
{
$version = $line[version];
}
}
mysql_free_result($result);
mysql_close();
$data = base64_decode($_GET["nval"]);
$exp = explode("|",$data);
$pass = "1234";
if($exp[0]=="getpass")
{
select_db("stargate_t");
$query = "SELECT * FROM user";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[avkey] == $exp[1])
{
$name = $line[name];
$pass = $line[pass];
}
}
mysql_free_result($result);
mysql_close();
if($pass == "1234")
{
$name = $exp[3];
$pass = random_string($length = 8, $characters_array = false, $mode = 4, $test_mode = false);
select_db("stargate_t");
mysql_query("INSERT INTO user(id,avkey,name,pass)VALUES(NULL, '$exp[1]', '$name', '$pass')");
mysql_close();
}
$out = base64_encode("pass|Your Login Name: $name Networkpassword: $pass \n Downloading new Firmware| $version ");
echo"$out";
}
?>
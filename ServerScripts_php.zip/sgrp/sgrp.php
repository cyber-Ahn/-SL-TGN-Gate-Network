<?php 
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$exp = explode(";",$data);
$expb = explode("|",$data);
$command = $exp[0];
$commandb = $expb[0];
if($command == "holo")
{
$texture = $exp[1];
$sound = $exp[2];
$size = $exp[3];
$smail = $exp[4];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$send = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$print = base64_encode("api-sgrp|holo|$texture|$sound|$size");
send_http_sl("4",$print,$send);
}
if($commandb == "object")
{
$name = $expb[1];
$speed = $expb[2];
$expc = explode(";",$speed);
$speed = $expc[0];
$smail = $expc[1];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$send = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$print = base64_encode("api-sgrp|object|$name|$speed");
send_http_sl("4",$print,$send);
}
?>
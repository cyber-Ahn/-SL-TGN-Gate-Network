<?php
include("../liberay/lib.php"); 
$data = base64_decode($_GET["nval"]);
$exp = explode("|",$data);
$name = $exp[1];
$smail = $exp[2];
$is = "no";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$found = $line[products];
}
}
mysql_free_result($result);
mysql_close();
if(eregi($name,$found))
{
$is = "yes";
}
$exp_is = explode("|",$found);
if($exp[0]=="reg"&&$is=="no")
{
$found = "$found$name|";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail] == $smail)
{
$aendern = "UPDATE gates Set
products = '$found'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
if($exp[0]=="ureg"&&$is=="yes")
{
$found_in ="";
$len = count($exp_is);
for($i=0;$i<=($len-2);$i++)
{
if(eregi($exp_is[$i],$name))
{
}
else
{
$found_in = "$found_in$exp_is[$i]|";
}
}
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail] == $smail)
{
$aendern = "UPDATE gates Set
products = '$found_in'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
?>
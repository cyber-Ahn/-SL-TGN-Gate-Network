<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$exp = explode("|",$data);
$command = $exp[0];
$message = $exp[1];
$avatar = $exp[2];
$dat = $exp[3];
$avatarkey = $exp[4];
$adminmenu = "Delete,Reset,Restart,Remove Scripts,Obj Name,Obj Desc";
$adminmenut = "ADMINFUNCTIONS! BE CAREFUL!";
if($command == "admin" && $message == "/admin")
{
$userdatei = fopen($dat,"r");
while(!feof($userdatei))
{
$zeile = fgets($userdatei,1024);
}
fclose($userdatei);
$zeile = base64_decode($zeile);
if(eregi($avatar,$zeile))
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|$adminmenu|$adminmenut|$avatarkey|$channel");
echo"$out";
}
}
?>
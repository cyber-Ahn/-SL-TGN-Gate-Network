<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$expa = explode("|",$data);
$key_ob = $expa[0];
$namevalue = $expa[1];
$simvalue = $expa[2];
$kordi = $expa[3];
$ownervalue = $expa[4];
$channel = $expa[5];
$model = $expa[6];
$radkanal = $expa[7];
$smail = $key_ob;
$displowner = $expa[8];
$gateage = $expa[9];
$typos = $expa[10];
$rdn = $expa[11];
if($rdn=="")
{
$rdn = "1";
}
$allow = 0;
$nwid = generate_network_id($model);
$datasvalue = generate_add($model);
$chan_send;
$sound_close;
$cach_name = explode("-",$namevalue);
if($cach_name[1] != "")
{
$namevalue = "$cach_name[0]_$cach_name[1]";
}
$search_url = encodesearchurlprofil($ownervalue);
$load_data = slProfil($search_url,"image");
if(eregi(strtolower("//DTD XHTML 1.0 Transitional//EN"),strtolower($load_data)))
{
$load_data = "";
}
include ("../liberay/stargate_t.php");
$query = "SELECT * FROM settings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($typos==$line[typos])
{
$chan_send = $line[channel];
$sound_close = $line[close];
}
}
mysql_free_result($result);
mysql_close();
$mai = "Registration complete";
include ("../liberay/stargate_t.php");
$query = "SELECT * FROM bann";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name]== $simvalue)
{
$allow = 1;
$mai = "Server Security: This Sim is blocked from this System,too many contacts.Please contact Support Team for more information.";
}
if($line[name]== $ownervalue)
{
$allow = 1;
$mai = "You are blocked from this System. Please contact Support Team";
}
if(eregi(strtolower($line[name]),strtolower($channel)))
{
$allow = 1;
$mai = "Beta Grid is blocked for this Network";
}
}
mysql_free_result($result);
mysql_close();
if($allow == 0)
{
$found = "no";
include ("../liberay/stargate_t.php");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$found = "yes";
$rand_di = $line[randial];
}
}
mysql_free_result($result);
mysql_close();
if($rand_di=="1")
{
$rand_di = $rdn;
}



if($found == "yes")
{
include ("../liberay/stargate_t.php");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail] == $smail)
{
$timeping = time();
$aendern = "UPDATE gates Set
name = '$namevalue',
model = '$model',
kordi = '$kordi',
channel = '$channel',
radkanal = '$radkanal',
pingc = '$timeping',
randial = '$rand_di',
imageowner = '$load_data'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
$out_b = "Data Updated<br>$chan_send<br>$sound_close";
$stat_ir = $line[gatestatus];
$mails = $line[smail];
$av_own = $line[owner];
$iris_type = $line[iristype];
}
}
mysql_free_result($result);
mysql_close();
if($iris_type != "" && $iris_type != "empty")
{
$out = base64_encode("form|$iris_type");
echo"$out_b<br>$out";
}
else
{
echo"$out_b";
}
$exp_iris = explode("|",$stat_ir);
$ir_cach = $exp_iris[2];
if($ir_cach == "1")
{
sleep(1); 
include ("../liberay/stargate_t.php");
$query = "SELECT * FROM user";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $av_own)
{
$av = $line[avkey];
}
}
mysql_free_result($result);
mysql_close();
$mailtext = base64_encode("shield raise|$av|45678765478578376");
$adri = "$mails@lsl.secondlife.com";
mail($adri, 'TGN Server',$mailtext);
}
}




if($found == "no")
{
$timeping = time();
include ("../liberay/stargate_t.php");
mysql_query("INSERT INTO gates(id,name,randial,sim,kordi,owner,datas,channel,gatestatus,imagesurl,model,ausf,prob,radkanal,rpsim,smail,rati,displowner,products,nwid,gateage,pingc,imageowner,iristype)VALUES(NULL, '$namevalue', '$rdn', '$simvalue', '$kordi', '$ownervalue', '$datasvalue', '$channel', '1|0|0', 'images/Atlantis.png!', '$model', 'empty', 'empty', '$radkanal', 'no', '$smail', '0', '$displowner', ' ', '$nwid', '$gateage', '$timeping', '$load_data','empty')");
mysql_close();
echo"$mai<br>Name changed to:$namevalue<br>$chan_send<br>$sound_close";
}
}
elseif($allow == 1)
{
echo"$mai";
include ("../liberay/stargate_t.php");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$sql = "DELETE FROM gates WHERE smail ='$smail' ";
$db_erg = mysql_query($sql)
    or die("Anfrage fehlgeschlagen: " . mysql_error());
}
}
mysql_free_result($result);
mysql_close();
}
$uuid = get_sim_uuid($simvalue);
$region = $simvalue;
$is = "no";
include ("../liberay/slmap.php");
$query = "SELECT * FROM sldb_data";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[field]==$region)
{
$is = "yes";
}
}
mysql_free_result($result);
mysql_close();
if($is == "no")
{
include ("../liberay/slmap.php");
mysql_query("INSERT INTO sldb_data(id,field,value)VALUES(NULL , '$region', '$uuid')");
mysql_close();
}
if($is == "yes")
{
include ("../liberay/slmap.php");
$aendern = "UPDATE sldb_data Set value = '$uuid' WHERE field = '$region'"; 
$update = mysql_query($aendern);
mysql_free_result($result);
mysql_close();
}
?>
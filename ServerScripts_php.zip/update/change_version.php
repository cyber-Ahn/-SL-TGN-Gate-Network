<?php
include("../liberay/lib.php");
$version = $_GET['ver'];
if($version != "")
{
$found = "no";
$id = "0";
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[version]!= "empty")
{
$id = $line[id];
$found = "yes";
}
}
mysql_free_result($result);
mysql_close();
echo "Found: $found / id: $id";
if($found == "no")
{
select_db("stargate_t");
mysql_query("INSERT INTO anisettings(id,chev_num,pos,glyph_num,glyph_tex,version)VALUES(NULL, 'empty', 'empty', 'empty','empty','$version')");
mysql_close();
}
if($found == "yes")
{
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$aendern = "UPDATE anisettings Set
version = '$version'
WHERE id = '$id'"; 
$update = mysql_query($aendern);
}
mysql_free_result($result);
mysql_close();
}
}
else
{
echo"<FORM METHOD='GET' ACTION='change_version.php'>";
echo"<INPUT name='ver' type='text' size='30' maxlength='20' value='New version number is ?'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
}
?>
<?php
include("../liberay/lib.php");
select_db("stargate_t");
$sql = "DROP TABLE IF EXISTS `backup`";
$db_erg = mysql_query($sql);
mysql_close();
select_db("stargate_t");
$sql = "CREATE TABLE `backup` SELECT * FROM `gates`";
$db_erg = mysql_query($sql);
mysql_close();
echo"ready";
?>
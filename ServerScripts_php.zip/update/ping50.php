<?php
include("../liberay/lib.php");
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY sim";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$opentime = $line[opent];
$contact = $line[pingc];
$kana = $line[smail];
if($contact == "0")
{
$sql = "DELETE FROM gates WHERE smail ='$kana' ";
$db_erg = mysql_query($sql);
}
$check = time() - $contact;
if($check >= "43300")
{
$sql = "DELETE FROM gates WHERE smail ='$kana' ";
$db_erg = mysql_query($sql);
}
if($opentime != "0")
{
$check2 = time() - $opentime;
if($check2 >= "2700")
{
$cachclose = $line[radkanal];
$data = base64_encode("gate_close");
send_http_sl("7",$data,$cachclose);
}
}
}
mysql_free_result($result);
mysql_close();
echo"ready";
?>
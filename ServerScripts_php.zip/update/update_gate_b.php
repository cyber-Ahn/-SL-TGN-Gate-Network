<?php
include("../liberay/lib.php");
$datasvalue = base64_decode($_GET["dval"]);
$intvalue = base64_decode($_GET["ival"]);
$dringvalue = base64_decode($_GET["xval"]);
$obkeyvalue = base64_decode($_GET["oval"]);
$channel = base64_decode($_GET["cval"]); 
    function code($wert,$daten,$kanal)
    {
		$xmldata = "<?xml version=\"1.0\"?><methodCall><methodName>llRemoteData</methodName>
		<params><param><value><struct>
		<member><name>Channel</name><value><string>".$kanal."</string></value></member>
		<member><name>IntValue</name><value><int>".$wert."</int></value></member>
		<member><name>StringValue</name><value><string>".$daten."</string></value></member>
		</struct></value></param></params></methodCall>";
    	sendToHost("xmlrpc.secondlife.com", "POST", "/cgi-bin/xmlrpc.cgi", $xmldata);
    }
    
if($intvalue == 1)
{
echo"start";
$update = "0";
$exp = explode("|",$datasvalue);
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $exp[1])
{
$update = "1";
}
}
mysql_free_result($result);
mysql_close();
if($update == "0")
{
select_db("stargate_t");
$gatestatus = "empty";
mysql_query("INSERT INTO product(id,name,vers,kana,pass,dring,obkey)VALUES(NULL , '$exp[1]', '$exp[2]', '$channel', '$exp[0]', '$dringvalue', '$obkeyvalue')");
mysql_close();
}
if($update == "1")
{
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $exp[1])
{
$aendern = "UPDATE product Set
vers = '$exp[2]' , dring = '$dringvalue' , kana = '$channel' , pass = '$exp[0]' , obkey = '$obkeyvalue' 
WHERE name = '$exp[1]'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}    
}
if($intvalue == 4)
{
$updateb = "0";
$expb = explode("|",$datasvalue);
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $expb[1] && $line[pass] == $expb[0])
{
if($line[vers] == $expb[2])
{
}
else
{
$updateb = "1";
$knalb1 = $line[kana];
$onkey = $line[obkey];
}
}
}
mysql_free_result($result);
mysql_close();
if($updateb == "1")
{
$datas1 = $expb[3]."|".$expb[1];
code("2",$datas1,$knalb1);
}
}
if($intvalue == 6)
{
$expc = explode("|", $datasvalue);
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $expc[1])
{
$knalb2 = $line[kana];
$onkey = $line[obkey];
}
}
mysql_free_result($result);
mysql_close();
code("2",$datasvalue,$knalb2);
}
?>
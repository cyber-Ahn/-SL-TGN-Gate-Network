<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<FORM METHOD='GET' ACTION='update_restart_50.php'>
<INPUT name="min" type="text" size="5" maxlength="4" value="0">
<INPUT name="max" type="text" size="5" maxlength="4" value="20">
<INPUT TYPE ='SUBMIT' VALUE='Start'></INPUT></FORM>
<?php
include("../liberay/lib.php");
$min = $_GET['min'];
$max = $_GET['max'];
$spal = "rati DESC, name ASC";
$a5 = "restart";

select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
$total = mysql_num_rows($result);
mysql_free_result($result);
mysql_close();

$data = "";
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY $spal LIMIT $min,$max";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$data = $data.$line[smail]."|";
$owner = $owner.$line[owner]."|";
}
mysql_free_result($result);
mysql_close();


echo "listdata: $data";

echo "<br><br>";

$exp = explode("|",$data);
$expA = explode("|",$owner);
$len = (count($exp)-1);
$maxA = $min + ($max - 1);

echo "length: $len / Data from line $min to $maxA / Total: $total";

echo "<br><br>";

for ($i = 0; $i <= ($len-1); $i++) 
{
    $num = ($i+$min);
    $adri = "$exp[$i]@lsl.secondlife.com";
    $av = $expA[$i];
    
    
    select_db("stargate_t");
    $query = "SELECT * FROM user";
    $result = mysql_query($query);
    while ($line = mysql_fetch_array($result))
    {
        if ($av == $line[name])
        {
          $av = $line[avkey];
        }
    }
    mysql_free_result($result);
    mysql_close();
    
    
    
    
    $pos = strpos($av, "-");
    if($pos != 0)
    {
        $mailtext = base64_encode("$a5|$av|45678765478578376");
        echo "$num - $adri / ".base64_decode($mailtext)."<br>";
        mail($adri, 'TGN Server',$mailtext);
        sleep(5);
    }
}







?>
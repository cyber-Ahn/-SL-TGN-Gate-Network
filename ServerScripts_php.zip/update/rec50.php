<?php
include("../liberay/lib.php");
$addi = "46";
select_db("stargate_t");
$query = "SELECT * FROM user";
$result = mysql_query($query);
$totaluser = mysql_num_rows($result);
mysql_free_result($result);
mysql_close();
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
$total = mysql_num_rows($result);
mysql_free_result($result);
mysql_close();
$total = $total +$addi;
$time = time();
select_db("stargate_t");
mysql_query("INSERT INTO rec_stat(id,user,gate,tim)VALUES(NULL, '$totaluser', '$total', '$time')");
mysql_close();
echo"ready";
?>
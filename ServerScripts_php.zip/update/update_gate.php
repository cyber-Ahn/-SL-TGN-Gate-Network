<?php
include("../liberay/lib.php");
$datasvalue = $_POST["dval"];
$intvalue = $_POST["ival"];
$channel = $_POST["cval"];
$xmldata = "<?xml version=\"1.0\"?><methodCall><methodName>llRemoteData</methodName>
<params><param><value><struct>
<member><name>Channel</name><value><string>".$channel."</string></value></member>
<member><name>IntValue</name><value><int>".$intvalue."</int></value></member>
<member><name>StringValue</name><value><string>".$namevalue."</string></value></member>
</struct></value></param></params></methodCall>";
    sendToHost("xmlrpc.secondlife.com", "POST", "/cgi-bin/xmlrpc.cgi", $xmldata);
if($intvalue == 1)
{
$update = "0";
$exp = explode("|",$datasvalue);
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $exp[1])
{
$update = "1";
}
}
mysql_free_result($result);
mysql_close();
if($update == "0")
{
select_db("stargate_t");
$gatestatus = "empty";
mysql_query("INSERT INTO product(id,name,vers,kana,pass)VALUES(NULL , '$exp[1]', '$exp[2]', '$channel', '$exp[0]')");
mysql_close();
}
elseif($update == "1")
{
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $exp[1])
{
$aendern = "UPDATE product Set
vers = '$exp[2]'
WHERE name = '$exp[1]'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
}
if($intvalue == 4)
{
$updateb = "0";
$expb = explode("|",$datasvalue);
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $expb[1] && $line[pass] == $expb[0])
{
if($line[vers] == $expb[2])
{
}
else
{
$updateb = "1";
$knalb1 = $line[kana];
}
}
}
mysql_free_result($result);
mysql_close();
if($updateb == "1")
{
$intvalue1 = "2";
$datas1 = $expb[3]."|".$expb[1];
$xmldata1 = "<?xml version=\"1.0\"?><methodCall><methodName>llRemoteData</methodName>
<params><param><value><struct>
<member><name>Channel</name><value><string>".$knalb1."</string></value></member>
<member><name>IntValue</name><value><int>".$intvalue1."</int></value></member>
<member><name>StringValue</name><value><string>".$datas1."</string></value></member>
</struct></value></param></params></methodCall>";
    sendToHost("xmlrpc.secondlife.com", "POST", "/cgi-bin/xmlrpc.cgi", $xmldata1);
echo"Update found";
}
}
if($intvalue == 6)
{
$expc = explode("|", $datasvalue);
select_db("stargate_t");
$query = "SELECT * FROM product";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $expc[1])
{
$knalb2 = $line[kana];
}
}
mysql_free_result($result);
mysql_close();
$intvalue2 = "2";
$datas2 = $datasvalue;
$xmldata2 = "<?xml version=\"1.0\"?><methodCall><methodName>llRemoteData</methodName>
<params><param><value><struct>
<member><name>Channel</name><value><string>".$knalb2."</string></value></member>
<member><name>IntValue</name><value><int>".$intvalue2."</int></value></member>
<member><name>StringValue</name><value><string>".$datas2."</string></value></member>
</struct></value></param></params></methodCall>";
    sendToHost("xmlrpc.secondlife.com", "POST", "/cgi-bin/xmlrpc.cgi", $xmldata2);
}
?>
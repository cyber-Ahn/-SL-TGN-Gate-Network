<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$glyph_pegasus = "0fbe8473-e03b-b9e6-54bb-6db407ceda7b";
$glyph_milkyway = "dffb8792-17e6-dde4-9ce2-6abc482938e9";
$glyph_clear = "8dcd4a48-2d37-4909-9f78-f7a9eb4ef903";
$prim = "display";
$repeat = "abc|<-0.45,0.38,0>|<-0.35,0.38,0>|<-0.25,0.38,0>|<-0.15,0.38,0>|<-0.05,0.38,0>|<0.05,0.38,0>|<0.15,0.38,0>|<0.25,0.38,0>|<0.35,0.38,0>|<0.45,0.38,0>|<-0.45,0.13,0>|<-0.35,0.13,0>|<-0.25,0.13,0>|<-0.15,0.13,0>|<-0.05,0.13,0>|<0.05,0.13,0>|<0.15,0.13,0>|<0.25,0.13,0>|<0.35,0.13,0>|<0.45,0.13,0>|<-0.45,-0.12,0>|<-0.35,-0.12,0>|<-0.25,-0.12,0>|<-0.15,-0.12,0>|<-0.05,-0.12,0>|<0.05,-0.12,0>|<0.15,-0.12,0>|<0.25,-0.12,0>|<0.35,-0.12,0>|<0.45,-0.12,0>|<-0.45,-0.37,0>|<-0.35,-0.37,0>|<-0.25,-0.37,0>|<-0.15,-0.37,0>|<-0.05,-0.37,0>|<0.05,-0.37,0>|<0.15,-0.37,0>|<0.25,-0.37,0>|<0.35,-0.37,0>|<0.45,-0.37,0>";
$cach = explode("|",$data);
if($cach[0]=="-805000")
{
if($cach[1]!="clear")
{
$glyph_num = explode(",",$cach[1]);
$count = count($glyph_num);
$data_out = "set|$glyph_pegasus|$count|$prim|";
$cach_b = explode("|",$repeat);
for($i="0";$i<=($count-1);$i++)
{
$select = $glyph_num[$i];
$data_out = "$data_out$cach_b[$select]#";
}
echo"$data_out";
}
else
{
echo"$cach[1]|$prim|$glyph_clear";
}
}
if($cach[0]=="-905000")
{
if($cach[1]!="clear")
{
$glyph_num = explode(",",$cach[1]);
$count = count($glyph_num);
$data_out = "set|$glyph_milkyway|$count|$prim|";
$cach_b = explode("|",$repeat);
for($i="0";$i<=($count-1);$i++)
{
$select = $glyph_num[$i];
$data_out = "$data_out$cach_b[$select]#";
}
echo"$data_out";
}
else
{
echo"$cach[1]|$prim|$glyph_clear";
}
}
?>
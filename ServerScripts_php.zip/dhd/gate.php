<?php
include("../liberay/lib.php");
$strvalue = $_POST["sval"];
$intvalue = $_POST["ival"];
$channel = $_POST["dkey"];
$ownvalue =  $_POST["oval"];
$datvalue = $_POST["dval"];
if ($intvalue == "1")
{
$xmldata = "<?xml version=\"1.0\"?><methodCall><methodName>llRemoteData</methodName>
<params><param><value><struct>
<member><name>Channel</name><value><string>".$channel."</string></value></member>
<member><name>IntValue</name><value><int>".$intvalue."</int></value></member>
<member><name>StringValue</name><value><string>".$strvalue."</string></value></member>
</struct></value></param></params></methodCall>";
    sendToHost("xmlrpc.secondlife.com", "POST", "/cgi-bin/xmlrpc.cgi", $xmldata);
}
?>
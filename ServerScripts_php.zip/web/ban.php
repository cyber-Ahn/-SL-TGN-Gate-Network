
<div align="center"><font size="+2">Ban List<br>
<div align="center"><font size="-1">
<form action="input.php" method="post">
<input type="text" size="20" maxlength="40" value="Name or Sim" name="v1">
<input type="text" size="20" maxlength="200" value="Reason" name="v2">
<input type="submit" value="ADD">
<br><br><br><br><br><br><br><br>
</input>
</form>
<TABLE>
<TR><TH>DATA &nbsp<br><br>
<?php
include ("../liberay/lib.php");
select_db("stargate_t");
$query = "SELECT * FROM bann";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
echo "
      <tc>
      <TR><TH>$line[name]&nbsp&nbsp
      <TH>$line[reason]&nbsp&nbsp
      <TH><a href=\"del.php?one=".base64_encode($line[name])."\"><img border='0' src='images/delete.png' width='15' height='15' alt='delete' ></a><br>";
}
mysql_free_result($result);
mysql_close();
echo "</TABLE>";
echo"<div align='center'><font size='-1'>";
?>
<br><a href="gate_list_member.php">back to Gatelist </a>
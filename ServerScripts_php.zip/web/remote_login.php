<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$ch = $_GET["ch"];
$name = $_GET["name"];
$p1 = $_GET["p1"];
$p2 = $_GET["p2"];
$p3 = $_GET["p3"];
$time = $_GET[tim];
if($time != "")
{
$time = "24 H";
}
$cookie = $_COOKIE["x1234yz"];
if($cookie != "")
{
$cookie = base64_decode($cookie);
$exp_cok = explode("|",$cookie);
$name = $exp_cok[0];
$p1 = $exp_cok[1];
}

$kk = "no";
select_db("stargate_t");
$query = "SELECT * FROM user";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name]!="")
{
$cachx = explode(" ",$line[name]);
$cachXa = strtolower($cachx[0]);
$cachXb = strtolower($cachx[1]);
$nameXa = "$cachXa.$cachXb";
if($cachx[1] == "Resident")
{
$nameXb = $cachx[0];
$nameXc = strtolower($cachx[0]);
}
if($line[name] == $name || strtolower($line[name])==$name || $nameXa == $name || $nameXb == $name || $nameXc == $name)
{
if($line[pass]== $p1)
{
$kk = "$line[name]|$line[avkey]";
}
}
}
}
mysql_free_result($result);
mysql_close();
if($kk != "no")
{
$kk = base64_encode($kk);
$datax = base64_encode("$name|$p1");
if($time == "24 H")
{
$time_set = time()+(3600*24);
}
if($time == "1 H")
{
$time_set = time()+(3600*1);
}
if($time == "4 H")
{
$time_set = time()+(3600*4);
}
if($time == "12 H")
{
$time_set = time()+(3600*12);
}
setcookie("x1234yz",$datax,$time_set);
echo"<br>Password ok";
echo "<META HTTP-EQUIV=REFRESH CONTENT='0; URL=remote_menu.php?one=$kk'><br>";
}
echo"
<div align='center'><font size='-1'>";

echo'<form action="remote_login.php" method="get">
Your SL Name<input type="text" size="20" maxlength="40" value="Name" name="name">No Displaynames &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>
Password<input type="password" size="20" maxlength="40" value="Password" name="p1">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>';
if($ch == "1")
{
echo'New Password<input type="password" size="20" maxlength="40" value="New Password" name="p2">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>';
echo'New Password<input type="password" size="20" maxlength="40" value="New Password" name="p3">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp<br>';
}
echo"<SELECT NAME='tim' SIZE=1  VALUE='$tim'>
<OPTION>24 H
<OPTION>4 H
<OPTION>12 H
<OPTION>1 H
</select>";
echo'<input type="submit" value="Login">';
if($ch != "1")
{
echo"<a href='remote_login.php?ch=1'>Change Password</a><br>";
}
if($p2 != "New Password" && $p3 != "")
{
if($p2 == $p3)
{
$p1 = $p3;
echo"<br> Password changed";
select_db("stargate_t");
$aendern = "UPDATE user Set
pass = '$p3'
WHERE name = '$name'"; 
$update = mysql_query($aendern);
mysql_close();
}
}
?>
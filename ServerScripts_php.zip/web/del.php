<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$name =  base64_decode($_GET["one"]);
select_db("stargate_t");
$query = "SELECT * FROM bann";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name] == $name)
{
$sql = "DELETE FROM bann WHERE name ='$name' ";
$db_erg = mysql_query($sql)
    or die("Anfrage fehlgeschlagen: " . mysql_error());
}
}
mysql_free_result($result);
mysql_close();
echo"<META HTTP-EQUIV=REFRESH CONTENT='1; URL=ban.php'>";
?>

<div align="center"><font size="-1"><font color="#000000">
<body link="#000000" vlink="#000000" text="#000000">
<div align="center"><font size="+2">Owner Delete<br>
<div align="center"><font size="-1">
<form action="owner_del.php" method="post">
<input type="text" size="20" maxlength="40" value="Avatar Name" name="v1">
<input type="submit" value="Delete">
<br><br><br><br><br><br><br><br>
</input>
</form>
<?php
include("../liberay/lib.php");
$name = $_POST["v1"];
if($name != "")
{
echo"Owner: $name<br>";
echo"Found and Delete:<br>";
$liste = "";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($name == $line[owner])
{
$gate = $line[name];
$liste = $liste.$line[channel]."|";
echo"$gate<br>";
}
}
mysql_free_result($result);
mysql_close();
echo"-------------------------------------------------------------------------------------------------<br>";
$exp = explode("|",$liste);
$lenc = count($exp);
for ($ic=0; $ic<$lenc; $ic++)
{
$channel = $exp[$ic];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[channel] == $channel)
{
$aendern = "UPDATE gates Set
ausf = 'delete_gate'
WHERE channel = '$channel'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo"<a href=$channel target='_blank'>$channel</a><br>";
}
}
?>
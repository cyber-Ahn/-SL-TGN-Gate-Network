<link rel=stylesheet href="data/styles/27.css" type="text/css"><BODY>
<font color="#FF0000"><H1><center>....<center><H1></font><br>
<?php
include("../liberay/lib.php");
$ownvalue =  base64_decode($_GET['one']);
$strvalue =  base64_decode($_GET['tow']);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[channel] == $ownvalue)
{
$aendern = "UPDATE gates Set
ausf = 'delete_gate'
WHERE channel = '$ownvalue'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo"<META HTTP-EQUIV=REFRESH CONTENT='0; URL=$ownvalue'>";
echo"<META HTTP-EQUIV=REFRESH CONTENT='5; URL=gate_list_member.php'>";
?>

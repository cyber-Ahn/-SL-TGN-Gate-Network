<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$chev_number = $_GET['chev'];
$texture_number = $_GET['texture'];
$pos = $_GET['pos'];
$pos_num = $_GET['pos_num'];
$texture_key = $_GET['texture_key'];
$texture_num = $_GET['texture_num'];
if($chev_number != "")
{
select_db("stargate_t");
mysql_query("INSERT INTO anisettings(id,chev_num,pos,glyph_num,glyph_tex)VALUES(NULL, '$chev_number', 'empty', 'empty', 'empty')");
mysql_close();
}
if($texture_number != "")
{
select_db("stargate_t");
mysql_query("INSERT INTO anisettings(id,chev_num,pos,glyph_num,glyph_tex)VALUES(NULL, 'enpty', 'empty', '$texture_number', 'empty')");
mysql_close();
}
if($pos != "")
{
echo"Saved Position $pos for Chevron $pos_num <br>";
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[chev_num] == $pos_num)
{
$aendern = "UPDATE anisettings Set
pos = '$pos'
WHERE chev_num = '$pos_num'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
if($texture_key != "")
{
echo"Saved Position $pos for Chevron $pos_num <br>";
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[glyph_num] == $texture_num)
{
$aendern = "UPDATE anisettings Set
glyph_tex = '$texture_key'
WHERE glyph_num = '$texture_num'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
echo"Ani settings for Pegasus Gates <br> <br>";
echo"<FORM METHOD='GET' ACTION='ani_settings.php'>";
echo"<INPUT name='chev' type='text' size='30' maxlength='30' value='Cevron Number'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
echo"<FORM METHOD='GET' ACTION='ani_settings.php'>";
echo"<INPUT name='texture' type='text' size='30' maxlength='30' value='Texture Number'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
echo"Chevron Positions <br>";
select_db("stargate_t");
$query = "SELECT * FROM anisettings ORDER BY chev_num";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[chev_num] != "enpty")
{
echo"<FORM METHOD='GET' ACTION='ani_settings.php'>";
echo "$line[chev_num] <INPUT name='pos' type='text' size='40' maxlength='40' value='$line[pos]'><INPUT TYPE='HIDDEN' NAME='pos_num' VALUE='$line[chev_num]'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
}
}
mysql_free_result($result);
mysql_close();
echo"Texture Keys <br>";
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[glyph_num] != "empty")
{
echo"<FORM METHOD='GET' ACTION='ani_settings.php'>";
echo "$line[glyph_num] <INPUT name='texture_key' type='text' size='40' maxlength='40' value='$line[glyph_tex]'><INPUT TYPE='HIDDEN' NAME='texture_num' VALUE='$line[glyph_num]'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
}
}
mysql_free_result($result);
mysql_close();
?>
<?php
include("../liberay/lib.php");
$pixe = "50";
$channel =  base64_decode($_GET['one']);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[channel] == $channel)
{
$name = $line[name];
$sim = $line[sim];
$kordi = $line[kordi];
$owner = $line[owner];
$datas = $line[datas];
$gatestat = $line[gatestatus];
$imageurl = $line[imagesurl];
$ver = $line[model];
}
}
mysql_free_result($result);
mysql_close();
$expi = explode("!",$imageurl);
$imageurl = $expi[0];
echo "<div style='position:absolute; top:50px'><img src=$imageurl width='125' height='125' alt='gateimage'></div>";
echo "<div align='center'><font size='+2'>";
echo "Stargate Information from $name";
echo "<div align='center'><font size='-1'>";
echo "<br>Owner: $owner";
echo "<br>Region: $sim";
echo "<br>Typ/Version: $ver";
$exp = explode("|",$datas);
$expb = explode("|",$gatestat);
if($exp[2] == "1")
{
$typ = "Milkyway";
}
elseif($exp[2] == "2")
{
$typ = "Pegasus";
}
elseif($exp[2] == "3")
{
$typ = "Universe";
}
if($expb[0] == "1")
{
$gate = "Online";
}
elseif($expb[0] == "0")
{
$gate = "Offline";
}
if($expb[1] == "1")
{
$sta = "Open";
}
elseif($expb[1] == "0")
{
$sta = "Idle";
}
if($expb[2] == "1")
{
$iri = "Closed";
}
elseif($expb[2] == "0")
{
$iri = "Open";
}
if($typ == "Milkyway")
{
echo "<div align='center'><font size='+0'>";
$expm = explode(": ",$exp[0]);
$expmw = explode(", ",$expm[1]);
$xs = $expmw[0];
$xsa = $expmw[1];
$xsb = $expmw[2];
$xsc = $expmw[3];
$xsd = $expmw[4];
$xse = $expmw[5];
$expp = explode(": ",$exp[1]);
$exppw = explode(", ",$expp[1]);
$xy = $exppw[0];
$xya = $exppw[1];
$xyb = $exppw[2];
$xyc = $exppw[3];
$xyd = $exppw[4];
$xye = $exppw[5];
$xyf = $exppw[6];
$expu = explode(": ",$exp[3]);
$expuw = explode(", ",$expu[1]);
$xu = $expuw[0];
$xua = $expuw[1];
$xub = $expuw[2];
$xuc = $expuw[3];
$xud = $expuw[4];
$xue = $expuw[5];
$xuf = $expuw[6];
$xug = $expuw[7];
echo "<br><br><img src=images/mw/$xs.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsa.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xse.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#c02c30'><br>$xs &nbsp &nbsp &nbsp $xsa &nbsp &nbsp &nbsp $xsb &nbsp &nbsp &nbsp $xsc &nbsp &nbsp &nbsp $xsd &nbsp &nbsp &nbsp $xse";
echo "<br><img src=images/pw/$xy.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xya.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xye.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyf.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#4747e8'><br>$xy &nbsp &nbsp &nbsp $xya &nbsp &nbsp &nbsp $xyb &nbsp &nbsp &nbsp $xyc &nbsp &nbsp &nbsp $xyd &nbsp &nbsp &nbsp $xye &nbsp &nbsp &nbsp $xyf";
echo "<br><img src=images/uw/$xu.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xua.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xub.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuc.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xud.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xue.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuf.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xug.png width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#000000'><br>$xu &nbsp &nbsp &nbsp $xua &nbsp &nbsp &nbsp $xub &nbsp &nbsp &nbsp $xuc &nbsp &nbsp &nbsp $xud &nbsp &nbsp &nbsp $xue &nbsp &nbsp &nbsp $xuf &nbsp &nbsp &nbsp $xug";
}
elseif($typ == "Pegasus")
{
echo "<div align='center'><font size='+0'>";
$expm = explode(": ",$exp[0]);
$expmw = explode(", ",$expm[1]);
$xs = $expmw[0];
$xsa = $expmw[1];
$xsb = $expmw[2];
$xsc = $expmw[3];
$xsd = $expmw[4];
$xse = $expmw[5];
$xsf = $expmw[6];
$expp = explode(": ",$exp[1]);
$exppw = explode(", ",$expp[1]);
$xy = $exppw[0];
$xya = $exppw[1];
$xyb = $exppw[2];
$xyc = $exppw[3];
$xyd = $exppw[4];
$xye = $exppw[5];
$expu = explode(": ",$exp[3]);
$expuw = explode(", ",$expu[1]);
$xu = $expuw[0];
$xua = $expuw[1];
$xub = $expuw[2];
$xuc = $expuw[3];
$xud = $expuw[4];
$xue = $expuw[5];
$xuf = $expuw[6];
$xug = $expuw[7];
echo "<br><img src=images/mw/$xs.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsa.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xse.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsf.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#c02c30'><br>$xs &nbsp &nbsp &nbsp $xsa &nbsp &nbsp &nbsp $xsb &nbsp &nbsp &nbsp $xsc &nbsp &nbsp &nbsp $xsd &nbsp &nbsp &nbsp $xse &nbsp &nbsp &nbsp $xsf";
echo "<br><br><img src=images/pw/$xy.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xya.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xye.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#4747e8'><br>$xy &nbsp &nbsp &nbsp $xya &nbsp &nbsp &nbsp $xyb &nbsp &nbsp &nbsp $xyc &nbsp &nbsp &nbsp $xyd &nbsp &nbsp &nbsp $xye";
echo "<br><img src=images/uw/$xu.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xua.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xub.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuc.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xud.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xue.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuf.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xug.png width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#000000'><br>$xu &nbsp &nbsp &nbsp $xua &nbsp &nbsp &nbsp $xub &nbsp &nbsp &nbsp $xuc &nbsp &nbsp &nbsp $xud &nbsp &nbsp &nbsp $xue &nbsp &nbsp &nbsp $xuf &nbsp &nbsp &nbsp $xug";
}
elseif($typ == "Universe")
{
echo "<div align='center'><font size='+0'>";
$expm = explode(": ",$exp[0]);
$expmw = explode(", ",$expm[1]);
$xs = $expmw[0];
$xsa = $expmw[1];
$xsb = $expmw[2];
$xsc = $expmw[3];
$xsd = $expmw[4];
$xse = $expmw[5];
$xsf = $expmw[6];
$xsg = $expmw[7];
$expp = explode(": ",$exp[1]);
$exppw = explode(", ",$expp[1]);
$xy = $exppw[0];
$xya = $exppw[1];
$xyb = $exppw[2];
$xyc = $exppw[3];
$xyd = $exppw[4];
$xye = $exppw[5];
$xyf = $exppw[6];
$expu = explode(": ",$exp[3]);
$expuw = explode(", ",$expu[1]);
$xu = $expuw[0];
$xua = $expuw[1];
$xub = $expuw[2];
$xuc = $expuw[3];
$xud = $expuw[4];
$xue = $expuw[5];
echo "<br><img src=images/mw/$xs.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsa.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xse.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsf.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsg.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#c02c30'><br>$xs &nbsp &nbsp &nbsp $xsa &nbsp &nbsp &nbsp $xsb &nbsp &nbsp &nbsp $xsc &nbsp &nbsp &nbsp $xsd &nbsp &nbsp &nbsp $xse &nbsp &nbsp &nbsp $xsf &nbsp &nbsp &nbsp $xsg";
echo "<br><br><img src=images/pw/$xy.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xya.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xye.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyf.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#4747e8'><br>$xy &nbsp &nbsp &nbsp $xya &nbsp &nbsp &nbsp $xyb &nbsp &nbsp &nbsp $xyc &nbsp &nbsp &nbsp $xyd &nbsp &nbsp &nbsp $xye &nbsp &nbsp &nbsp $xyf";
echo "<br><img src=images/uw/$xu.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xua.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xub.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuc.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xud.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xue.png width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#000000'><br>$xu &nbsp &nbsp &nbsp $xua &nbsp &nbsp &nbsp $xub &nbsp &nbsp &nbsp $xuc &nbsp &nbsp &nbsp $xud &nbsp &nbsp &nbsp $xue";
}
echo "<div align='center'><font size='-1'>";
echo "<br><br>Last 20 Connections";
$expver = explode("#",$expi[1]);
$lenc = count($expver);
for ($ic=0; $ic<$lenc; $ic++)
{
echo "<br>$expver[$ic]";
}
?>
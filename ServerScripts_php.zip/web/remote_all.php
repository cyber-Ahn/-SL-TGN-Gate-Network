<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$entries = 20;
$site = $_GET['page'];
$datas = base64_decode($_GET["one"]);
$datas_b = base64_encode($datas);
$exp = explode("|",$datas);
$name = $exp[0];
$avkey = $exp[1];
if($site == "")
{
$site = "0";
}
$out = $site / $entries;
$out = $out + 1;
echo"<br>PAGE $out<br>";
echo"Gates From GOD";
echo" <a href='logout.php'>Logout</a><br><br><br><br><br><br>";
echo"<TABLE>
<TR>
	<TH><font size='-1'>Gate Name &nbsp &nbsp
    <TH><font size='-1'>Sim &nbsp &nbsp
    <TH><font size='-1'>Typ/Version &nbsp";
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY name LIMIT $site,$entries";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$kan = base64_encode($line[channel]);
$avkey = name2Key($line[owner]);
echo '<br><br>
      <tc>
      <TR>';
echo"     <TH><form action='remote_action.php' method='get'>
			  <INPUT TYPE='HIDDEN' NAME='one' VALUE='$kan'>
			  <INPUT TYPE='HIDDEN' NAME='av' VALUE='$avkey'>
			  <input type='submit' value='$line[name]'style='width:150px;height:30px;'>
			  </input></form>&nbsp &nbsp
          <TH><font size='-1'>$line[sim]&nbsp&nbsp
	  	  <TH><font size='-1'>$line[model]&nbsp&nbsp";
}
mysql_free_result($result);
mysql_close();
echo "</TABLE>";
$ar = $site + $entries;
if($site == 0)
{
$arb = 0;
}
else
{
$arb = $site - $entries;
}
echo"<font size='-1'><a href=\"remote_all.php?page=".$arb."&one=".$datas_b."\"><img border='0' src='images/arrow-left.png' width='15' height='15' alt='back' ></a> ";
echo"<font size='-1'><a href=\"remote_all.php?page=".$ar."&one=".$datas_b."\"><img border='0' src='images/arrow-right.png' width='15' height='15' alt='next' ></a><br>";
?>
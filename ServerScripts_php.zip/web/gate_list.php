<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<FORM METHOD='GET' ACTION='gate_list.php'>
<SELECT NAME='colu' SIZE=1  VALUE='$spal'>
<OPTION>Rating
<OPTION>Name
<OPTION>Sim
<OPTION>Owner
<OPTION>GateAge
</select>
<input type="checkbox" name="imgs" value="imgon"> only with Image
<INPUT TYPE ='SUBMIT' VALUE='ORDER'></INPUT></FORM>
<FORM METHOD='GET' ACTION='gate_list.php'>
<INPUT name="nsearch" type="text" size="30" maxlength="50" value="Gate Network Home">
<INPUT TYPE ='SUBMIT' VALUE='Search'></INPUT></FORM>
<?php
include("../liberay/lib.php");
$n_search = $_GET['nsearch'];
$ima = $_GET['imgs'];
$entries = 20;
$site = $_GET['page'];
$state_color = 1;
if($n_search == "")
{
$n_search = "empty";
}
$n_search = strtolower($n_search);
if($ima == "")
{
$ima = "imgoff";
}
if($site == "")
{
$site = "0";
}
$out = $site / $entries;
$out = $out + 1;
$spal = $_GET['colu'];
$spalb = $spal;
if($ima != "imgoff")
{
$simg = "only Gates with Image";
}
if($spalb == "rati DESC" || $spalb == "")
{
$spalb = "Rating";
}
if($spal == "GateAge")
{
$spal = "gateage DESC";
$spalb = "Age";
}
if($n_search == "empty")
{
echo"Search: Order by $spalb $simg";
}
elseif($n_search != "empty")
{
echo"Search: $n_search";
}
if($spal == "")
{
$spal = "rati DESC";
}
if($spal == "Rating")
{
$spal = "rati DESC, name ASC";
}
echo "<br><br><br><br><br>";
echo" <TABLE>
      <TR background='images/list_background_2.png'>
	    <TH><font size='-1'>Pic &nbsp
      <TH><font size='-1'>Gate Name &nbsp
      <TH><font size='-1'>Sim &nbsp
      <TH><font size='-1'>Typ/Version &nbsp
      <TH><font size='-1'>Image &nbsp
      <TH><font size='-1'>Owner &nbsp
      <TH><font size='-1'>Info &nbsp";
if($ima == "imgoff" && $n_search == "empty")
{
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY $spal LIMIT $site,$entries";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$nwid = $line[nwid];
$expc = explode("|",$line[datas]);
$address = $expc[0] ."<br>".$expc[1];
$imageurl = $line[imagesurl];
$expi = explode("!",$imageurl);
$imageurl = $expi[0];
$ins = 0;
$ins = substr_count($imageurl, '-');
$rp_sim = $line[rpsim];
$gate_state = $line[gatestatus];
$expx = explode("|",$gate_state);
$age = "";
$dbtime = $line[gateage];
$load_data = $line[imageowner];
$owner_link = $line[owner];
$cach_owner_link = explode(" ",$owner_link);
$first_owner = strtolower($cach_owner_link[0]);
$secound_owner = strtolower($cach_owner_link[1]);
$simrati = $line[simrati];
if($simrati== "")
{
$simrati = "no data";
}
else if($simrati == "MATURE")
{
$simrati = "M";
}
else if($simrati == "ADULT")
{
$simrati = "A";
}
else if($simrati == "GENERAL")
{
$simrati = "G";
}
if($cach_owner_link[1]=="Resident")
{
$owner_link = "https://my.secondlife.com/$first_owner/#about_tab";
}
else
{
$owner_link = "https://my.secondlife.com/".$first_owner.".".$secound_owner."/#about_tab";
}
if(eregi(strtolower("Page Not Found"),strtolower($load_data))||$load_data == "")
{
$load_data = "images/empty_profil.png";
}
if($dbtime != "")
{
$cach = explode(" ",getdiffdate(unixtotime($dbtime),unixtotime(time())));
if($cach[0]!="0month")
{
$age = $age.$cach[0]." ";
}
if($cach[1]!="0week")
{
$age = $age.$cach[1]."<br>";
}
if($cach[2]!="0day")
{
$age = $age.$cach[2]." ";
}
if($cach[3]!="0hour")
{
$age = $age.$cach[3]." ";
}
if($cach[4]!="0min")
{
$age = $age.$cach[4]." ";
}
if($age != "")
{
$age = "Age:".$age;
}
}
if($ins == 4)
{
$imageurl = "http://secondlife.com/app/image/$imageurl/1";
}
else if($imageurl == "")
{
$imageurl = "images/Atlantis.png";
}
$rp_image = "images/norp.png";
if($rp_sim == "yes")
{
$rp_image = "images/rp.png";
}
else if ($expx[2] == "1")
{
$rp_image = "images/Iris.png";
}
if($state_color==1)
{  
echo '<br><br>
      <tc>
      <TR background="images/list_background_1.png"><TH>';
      $state_color=2;
}
else if($state_color==2)
{  
echo '<br><br>
      <tc>
      <TR background="images/list_background_2.png"><TH>';
      $state_color=1;
}     
?>
<html>
<head>
<script language="JavaScript" src="../liberay/overlib.js" type="text/javascript"></script>
</head>
<body>
<a href="#" target="_self" onmouseover="return overlib('<img src=<? echo $imageurl; ?> width=350 height=250 border=0 class=name/>');" onmouseout="nd();" alt=""/><img src=<? echo $imageurl; ?> border="0" width='50' height='50' alt='gateimage'></a>
</body>
</html>
<?php
echo"<br>
      <div align='center'><font size='-1'>$nwid
		  <TH><font size='-1'><a href=\"gate_detail.php?one=".base64_encode($line[channel])."\" >$line[name]&nbsp</a><br>
      <TH><font size='-1'>$line[sim] ($simrati)&nbsp&nbsp
      <TH><font size='-1'>$line[model]&nbsp&nbsp
      
		  <TH><font size='-1'>";
?>
<html>
<head>
<script language="JavaScript" src="../liberay/overlib.js" type="text/javascript"></script>
</head>
<body>
<a href="#" target="_self" onmouseover="return overlib('<img src=<? echo $load_data; ?> width=350 height=250 border=0 class=name/>');" onmouseout="nd();" alt=""/><img src=<? echo $load_data; ?> border="0" width='50' height='50' alt='gateimage'></a>
</body>
</html>
<?php 
echo"<TH><font size='-1'><a href=".$owner_link." target='_blank'>$line[owner]&nbsp</a><br>
     <TH><img src=$rp_image width='35' height='35' alt='rpimage'><br><font size='-2'>$age";
}
}
if($ima == "imgon" && $n_search == "empty")
{
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY $spal";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$nwid = $line[nwid];
$imageurl = $line[imagesurl];
$load_data = $line[imageowner];
$expi = explode("!",$imageurl);
$imageurl = $expi[0];
if($imageurl != "images/Atlantis.png"&&$imageurl != "")
{
$expc = explode("|",$line[datas]);
$address = $expc[0] ."<br>".$expc[1];
$ins = 0;
$ins = substr_count($imageurl, '-');
$rp_sim = $line[rpsim];
$gate_state = $line[gatestatus];
$dbtime = $line[gateage];
$age = "";
$expx = explode("|",$gate_state);
$simrati = $line[simrati];
if($simrati== "")
{
$simrati = "no data";
}
else if($simrati == "MATURE")
{
$simrati = "M";
}
else if($simrati == "ADULT")
{
$simrati = "A";
}
else if($simrati == "GENERAL")
{
$simrati = "G";
}
if($ins == 4)
{
$imageurl = "http://secondlife.com/app/image/$imageurl/1";
}
if(eregi(strtolower("Page Not Found"),strtolower($load_data))||$load_data == "")
{
$load_data = "images/empty_profil.png";
}
if($dbtime != "")
{
$cach = explode(" ",getdiffdate(unixtotime($dbtime),unixtotime(time())));
if($cach[0]!="0month")
{
$age = $age.$cach[0]." ";
}
if($cach[1]!="0week")
{
$age = $age.$cach[1]."<br>";
}
if($cach[2]!="0day")
{
$age = $age.$cach[2]." ";
}
if($cach[3]!="0hour")
{
$age = $age.$cach[3]." ";
}
if($cach[4]!="0min")
{
$age = $age.$cach[4]." ";
}
if($age != "")
{
$age = "Age:".$age;
}
}
$rp_image = "images/norp.png";
if($rp_sim == "yes")
{
$rp_image = "images/rp.png";
}
else if ($expx[2] == "1")
{
$rp_image = "images/Iris.png";
}
if($state_color==1)
{  
echo '<br><br>
      <tc>
      <TR background="images/list_background_1.png"><TH>';
      $state_color=2;
}
else if($state_color==2)
{  
echo '<br><br>
      <tc>
      <TR background="images/list_background_2.png"><TH>';
      $state_color=1;
}
?>
<html>
<head>
<script language="JavaScript" src="../liberay/overlib.js" type="text/javascript"></script>
</head>
<body>
<a href="#" target="_self" onmouseover="return overlib('<img src=<? echo $imageurl; ?> width=350 height=250 border=0 class=name/>');" onmouseout="nd();" alt=""/><img src=<? echo $imageurl; ?> border="0" width='50' height='50' alt='gateimage'></a>
</body>
</html>
<?php
echo"<br>
      <div align='center'><font size='-1'>$nwid
		  <TH><font size='-1'><a href=\"gate_detail.php?one=".base64_encode($line[channel])."\" >$line[name]&nbsp</a><br>
      <TH><font size='-1'>$line[sim] ($simrati)&nbsp&nbsp
      <TH><font size='-1'>$line[model]&nbsp&nbsp
      
		  <TH><font size='-1'>";
?>
<html>
<head>
<script language="JavaScript" src="../liberay/overlib.js" type="text/javascript"></script>
</head>
<body>
<a href="#" target="_self" onmouseover="return overlib('<img src=<? echo $load_data; ?> width=350 height=250 border=0 class=name/>');" onmouseout="nd();" alt=""/><img src=<? echo $load_data; ?> border="0" width='50' height='50' alt='gateimage'></a>
</body>
</html>
<?php 
echo" <TH><font size='-1'><a href=".$owner_link." target='_blank'>$line[owner]&nbsp</a><br>
      <TH><img src=$rp_image width='35' height='35' alt='rpimage'><br><font size='-2'>$age";
}
}
}
if($n_search != "empty")
{
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY $spal";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$nwid = $line[nwid];
$imageurl = $line[imagesurl];
$load_data = $line[imageowner];
$dbtime = $line[gateage];
$age = "";
$expi = explode("!",$imageurl);
$imageurl = $expi[0];
if(eregi($n_search,  strtolower($line[name])) || strtolower($line[sim]) == $n_search || strtolower($line[owner]) == $n_search)
{
$expc = explode("|",$line[datas]);
$address = $expc[0] ."<br>".$expc[1];
$ins = 0;
$ins = substr_count($imageurl, '-');
$rp_sim = $line[rpsim];
$gate_state = $line[gatestatus];
$expx = explode("|",$gate_state);
$simrati = $line[simrati];
if($simrati== "")
{
$simrati = "no data";
}
else if($simrati == "MATURE")
{
$simrati = "M";
}
else if($simrati == "ADULT")
{
$simrati = "A";
}
else if($simrati == "GENERAL")
{
$simrati = "G";
}
if(eregi(strtolower("Page Not Found"),strtolower($load_data))||$load_data == "")
{
$load_data = "images/empty_profil.png";
}
if($ins == 4)
{
$imageurl = "http://secondlife.com/app/image/$imageurl/1";
}
$rp_image = "images/norp.png";
if($rp_sim == "yes")
{
$rp_image = "images/rp.png";
}
if($dbtime != "")
{
$cach = explode(" ",getdiffdate(unixtotime($dbtime),unixtotime(time())));
if($cach[0]!="0month")
{
$age = $age.$cach[0]." ";
}
if($cach[1]!="0week")
{
$age = $age.$cach[1]."<br>";
}
if($cach[2]!="0day")
{
$age = $age.$cach[2]." ";
}
if($cach[3]!="0hour")
{
$age = $age.$cach[3]." ";
}
if($cach[4]!="0min")
{
$age = $age.$cach[4]." ";
}
if($age != "")
{
$age = "Age:".$age;
}
}
else if ($expx[2] == "1")
{
$rp_image = "images/Iris.png";
}
if($state_color==1)
{  
echo '<br><br>
      <tc>
      <TR background="images/list_background_1.png"><TH>';
      $state_color=2;
}
else if($state_color==2)
{  
echo '<br><br>
      <tc>
      <TR background="images/list_background_2.png"><TH>';
      $state_color=1;
}

?>
<html>
<head>
<script language="JavaScript" src="../liberay/overlib.js" type="text/javascript"></script>
</head>
<body>
<a href="#" target="_self" onmouseover="return overlib('<img src=<? echo $imageurl; ?> width=350 height=250 border=0 class=name/>');" onmouseout="nd();" alt=""/><img src=<? echo $imageurl; ?> border="0" width='50' height='50' alt='gateimage'></a>
</body>
</html>
<?php
echo"<br>
      <div align='center'><font size='-1'>$nwid
		  <TH><font size='-1'><a href=\"gate_detail.php?one=".base64_encode($line[channel])."\" >$line[name]&nbsp</a><br>
      <TH><font size='-1'>$line[sim] ($simrati)&nbsp&nbsp
      <TH><font size='-1'>$line[model]&nbsp&nbsp
      
		  <TH><font size='-1'>";
?>
<html>
<head>
<script language="JavaScript" src="../liberay/overlib.js" type="text/javascript"></script>
</head>
<body>
<a href="#" target="_self" onmouseover="return overlib('<img src=<? echo $load_data; ?> width=350 height=250 border=0 class=name/>');" onmouseout="nd();" alt=""/><img src=<? echo $load_data; ?> border="0" width='50' height='50' alt='gateimage'></a>
</body>
</html>
<?php 
echo" <TH><font size='-1'><a href=".$owner_link." target='_blank'>$line[owner]&nbsp</a><br>
      <TH><img src=$rp_image width='35' height='35' alt='rpimage'><br><font size='-2'>$age";      
}
}
}
mysql_free_result($result);
mysql_close();
echo "</TABLE>";
echo"<div align='center'><font size='-1'>";
$ar = $site + $entries;
if($site == 0)
{
$arb = 0;
}
else
{
$arb = $site - $entries;
}
if($n_search == "empty")
{
echo"<font size='-1'><a href=\"gate_list.php?page=".$arb."&colu=".$spal."&imgs=".$ima."\"><img border='0' src='images/arrow-left.png' width='25' height='25' alt='back' ></a> ";
echo"<font size='-1'><a href=\"gate_list.php?page=".$ar."&colu=".$spal."&imgs=".$ima."\"><img border='0' src='images/arrow-right.png' width='25' height='25' alt='next' ></a><br>";
}
echo"<div align='left'><font size='-1'>";
echo"<br><br>RP SIM:<img src=images/rp.png width='35' height='35' alt='image1'> <br><br>Iris closed:<img src=images/Iris.png width='35' height='35' alt='image2'>";
?>
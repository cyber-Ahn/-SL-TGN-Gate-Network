<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$chev_number = $_GET['chev'];
$pos = $_GET['pos'];
$tex = $_GET['tex'];
$pos_num = $_GET['pos_num'];
if($chev_number != "")
{
select_db("stargate_t");
mysql_query("INSERT INTO unisettings(id,chev_num,pos,glyph_tex)VALUES(NULL, '$chev_number', 'empty', 'empty')");
mysql_close();
}
if($pos != "")
{
select_db("stargate_t");
$query = "SELECT * FROM unisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[chev_num] == $pos_num)
{
$aendern = "UPDATE unisettings Set
pos = '$pos'
WHERE chev_num = '$pos_num'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
if($tex != "")
{
select_db("stargate_t");
$query = "SELECT * FROM unisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[chev_num] == $pos_num)
{
$aendern = "UPDATE unisettings Set
glyph_tex = '$tex'
WHERE chev_num = '$pos_num'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
echo"Ani settings for Universe Gates <br> <br>";
echo"<FORM METHOD='GET' ACTION='uni_settings.php'>";
echo"<INPUT name='chev' type='text' size='30' maxlength='30' value='Cevron Number'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
echo"Positions..........................UUID <br>";
select_db("stargate_t");
$query = "SELECT * FROM unisettings ORDER BY chev_num";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
echo"<FORM METHOD='GET' ACTION='uni_settings.php'>";
echo "$line[chev_num] <INPUT name='pos' type='text' size='40' maxlength='40' value='$line[pos]'><INPUT name='tex' type='text' size='40' maxlength='40' value='$line[glyph_tex]'><INPUT TYPE='HIDDEN' NAME='pos_num' VALUE='$line[chev_num]'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
}
mysql_free_result($result);
mysql_close();
?>
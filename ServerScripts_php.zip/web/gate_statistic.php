<?php
include ("../liberay/lib.php");
$milkyway = 0;
$pegasus = 0;
$tollan = 0;
$tula = 0;
$lowprim = 0;
$iconian = 0;
$universe = 0;
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{

if(eregi("Milkyway",  $line[model]))
{
$milkyway = $milkyway + 1;
}
if(eregi("Pegasus",  $line[model]))
{
$pegasus = $pegasus + 1;
}
if(eregi("Tollan",  $line[model]))
{
$tollan = $tollan + 1;
}
if(eregi("Tula",  $line[model]))
{
$tula = $tula + 1;
}
if(eregi("Low Prim",  $line[model]))
{
$lowprim = $lowprim + 1;
}
if(eregi("Iconian",  $line[model]))
{
$iconian = $iconian + 1;
}
if(eregi("Universe",  $line[model]))
{
$universe = $universe + 1;
}

}
mysql_free_result($result);
mysql_close();
echo"Milkyway: $milkyway <br>Pegasus: $pegasus <br>Tollan: $tollan <br>Tula: $tula <br>Lowprim: $lowprim <br>Iconian: $iconian <br>Universe: $universe";
?>
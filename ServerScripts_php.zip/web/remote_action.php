<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$mailtext = "empty";
$chan = base64_decode($_GET["one"]);
$av = $_GET["av"];
$xchan = base64_encode($chan);
$sed = base64_decode($_GET["befehl"]);
$sedb = $_GET["befehlb"];
$sedc = $_GET["befehlc"];
$sedd = $_GET["befehld"];
$sede = $_GET["befehle"];
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY name";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($chan == $line[channel])
{
$name =$line[name];
$mails = $line[smail];
$imageurl = $line[imagesurl];
$expi = explode("!",$imageurl);
$image = $expi[0];
$own = $line[owner];
$datas = $line[datas];
$randial = $line[randial];
$gatestat = $line[gatestatus];
$rp_sim = $line[rpsim];
$kk = base64_encode("$own|$av");
}
}
mysql_free_result($result);
mysql_close();
$exp = explode("|",$datas);
$expb = explode("|",$gatestat);
if($exp[2] == "1")
{
$typ = "Milkyway";
}
elseif($exp[2] == "2")
{
$typ = "Pegasus";
}
elseif($exp[2] == "3")
{
$typ = "Universe";
}
if($expb[0] == "1")
{
$gate = "Online";
}
elseif($expb[0] == "0")
{
$gate = "Offline";
}
if($expb[1] == "1")
{
$sta = "Open";
}
elseif($expb[1] == "0")
{
$sta = "Idle";
}
if($expb[2] == "1")
{
$iri = "Closed";
}
elseif($expb[2] == "0")
{
$iri = "Open";
}
if($randial == "1")
{
$randial = "On";
}
elseif($randial == "0")
{
$randial = "Off";
}
elseif($randial == "")
{
$randial = "---";
}
$a1 = base64_encode("shield raise");
$a2 = base64_encode("shield lower");
$a3 = base64_encode("delete");
$a4 = base64_encode("reset");
$a5 = base64_encode("restart");
$a8 = base64_encode("offline");
$a9 = base64_encode("online");
$a10 = base64_encode("randomlist on");
$a11 = base64_encode("randomlist off");
$a12 = base64_encode("rp on");
$a13 = base64_encode("rp off");
echo"Options for $name<br><br><br><br><br><br>";
echo"<TABLE>
	<TR background='images/list_background_1.png'>
	<TH><font size='-1'>IRIS: $iri
  <TH>
    ";
echo"<tc>
	 <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a1'><input type='image' src='images_r/raise.png' alt='x'></input></form>
     <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a2'><input type='image' src='images_r/lower.png' alt='x'></input></form>
     <TR background='images/list_background_1.png'>
     <TH><font size='-1'>GATE POWER: $gate
     <TH>
     <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a9'><input type='image' src='images_r/online.png' alt='x'></input></form>
     <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a8'><input type='image' src='images_r/offline.png' alt='x'></input></form>
	 ";
echo "
	<TR background='images/list_background_1.png'>
	<TH><font size='-1'>GATE-OPTIONS
  <TH>
	";
echo"<tc>
	 <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a4'><input type='image' src='images_r/reset.png' alt='x'></input></form>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a5'><input type='image' src='images_r/restart.png' alt='x'></input></form>
	 <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a3'><input type='image' src='images_r/delete.png' alt='x'></input></form>
	 <TH>
   ";
echo"
<TR background='images/list_background_1.png'>
	<TH><font size='-1'>RP_MODE: $rp_sim
  <TH>
";
echo"<tc>
 <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a12'><input type='image' src='images_r/on.png' alt='x'></input></form>
     <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a13'><input type='image' src='images_r/off.png' alt='x'></input></form>
     <TR background='images/list_background_1.png'>
     <TH><font size='-1'>RANDOMLIST: $randial
     <TH>
     <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a10'><input type='image' src='images_r/on.png' alt='x'></input></form>
     <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><INPUT TYPE='HIDDEN' NAME='befehl' VALUE='$a11'><input type='image' src='images_r/off.png' alt='x'></input></form>
	 ";
echo "
	<TR>
	<TR background='images/list_background_1.png'>
	<TH><font size='-1'>GATE-NAME
  <TH>
	";
echo"<tc>
 <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><input color&#58;#000000;' type='text' size='16' maxlength='15' value='$name' name='befehlb'><TH><input type='image' src='images_r/set.png' alt='x'></input></form>
	 ";
echo"</TABLE>";
echo "<br><br><br><br>";
echo "<TABLE>
	<TR>
	<TR background='images/list_background_1.png'>
	<TH><font size='-1'>GATE-IMAGE_URL
  <TH>
	";
echo"<tc>
 <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><input type='text' size='16' maxlength='150' value='$image' name='befehlc'><TH><input type='image' src='images_r/set.png' alt='x'></input></form>
	 ";
echo"</TABLE>";
echo "<br><br><br><br>";
echo "<TABLE>
	<TR>
	<TR background='images/list_background_1.png'>
	<TH><font size='-1'>DIAL OPTION
  <TH>
	";
echo"<tc>
 <TR background='images/list_background_2.png'>
	 <TH><form action='remote_action.php' method='get'><INPUT TYPE='HIDDEN' NAME='one' VALUE='$xchan'><INPUT TYPE='HIDDEN' NAME='av' VALUE='$av'><input type='text' size='16' maxlength='15' value='' name='befehle'><TH><input type='image' src='images_r/dial.png' alt='x'></input></form>
	 </TABLE>";
$ins = 0;
$ins = substr_count($image, '-');
if($ins == 4)
{
$image = "http://secondlife.com/app/image/$image/1";
}
if($sed != "")
{
echo"<br> Send command: $sed";
$mailtext = base64_encode("$sed|$av|45678765478578376");
$intvalue = "10";
}
if($sedb != "")
{
$sedb = "name:$sedb";
echo"<br> Send command: $sedb";
$mailtext = base64_encode("$sedb|$av|45678765478578376");
$intvalue = "10";
}
if($sedc != "")
{
$sedc = "image:$sedc";
echo"<br> Send command: $sedc";
$mailtext = base64_encode("$sedc|$av|45678765478578376");
$intvalue = "10";
}
if($sede != "")
{
$sedd = "/asg";
$xpse = explode("/",$sedd);
$sede = "dial:$xpse[1]-$sede";
echo"<br> Send command: $sede";
$mailtext = base64_encode("$sede|$av|45678765478578376");
$intvalue = "10";
}
echo"<br><a href='remote_menu.php?one=$kk'>BACK</a><br>";
echo"<br><img src=$image width='400' height='250' alt='gateimage'>";
if($mailtext != "empty")
{
$adri = "$mails@lsl.secondlife.com";
mail($adri, 'TGN Server',$mailtext);
}
?>
<?php
error_reporting(0);
setcookie("x1234yz",$datax,time()-(3600*1));
echo "<META HTTP-EQUIV=REFRESH CONTENT='0; URL=remote_login.php'><br>";
?>
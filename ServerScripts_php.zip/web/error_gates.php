
<div align="center"><font size="-1"><font color="#000000">
<body link="#000000" vlink="#000000" text="#000000">
Stargatelist ERROR Gates <br>
<?php
include ("../liberay/lib.php");
echo"<br><a href='error_gates.php'>Refresh</a>....<a href='logout.php'>Logout</a><br><br><br>";
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY name";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$gatestat = $line[gatestatus];
$expb = explode("|",$gatestat);
if($expb[1] == "1")
{
echo"$line[name] <font size='-1'><a href=\"restart.php?one=".base64_encode($line[channel])."&tow=".base64_encode($line[name])."\" target='_blank'><img border='0' src='images/restart.png' width='15' height='15' alt='restart' ></a><br><br><br>";
}
}
mysql_free_result($result);
mysql_close();
?>
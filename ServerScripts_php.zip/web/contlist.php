<link rel=stylesheet href="../liberay/style.css" type="text/css">
Last Gate Contacts
<br>
<div align="center"><font size="-1"><div background-color="#D8D8D8">
<style>
.gree { background-color:#D8D8D8; }
</style>

<?php 
include ("../liberay/lib.php");
select_db("stargate_t");
$query = "SELECT * FROM contacts ORDER BY timstart LIMIT 20";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$tim = $line[timend] - $line[timstart];
$timeAt = unixtotime($line[timstart]);
echo "<br><span class='gree'>$line[namefrom] to $line[nameto] for $tim seconds at $timeAt</span><br>";
}
mysql_free_result($result);
mysql_close();
?>
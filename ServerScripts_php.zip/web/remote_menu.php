<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="right"><font size="-1">
<?php
include("../liberay/lib.php");
$datas = base64_decode($_GET["one"]);
$datas_b = base64_encode($datas);
$exp = explode("|",$datas);
$name = $exp[0];
$avkey = $exp[1];
$god = "0";
if($name == "cyber Ahn")
{
$god = "1";
}
if($god == "1")
{
echo "You are the GOD<br>";
echo"<br><a href='http://caworks-sl.de/TGN/gate/update/change_version.php'>Version</a>....<a href='uni_settings.php'>Universe</a>....<a href='ani_settings.php'>Pegasus</a>....<a href='main_settings.php'>Main settings</a>....<a href='remote_all.php?one=$datas_b'>Remote ALL</a>....<a href='gate_list_member.php'>Member List & Ban</a>....<a href='error_gates.php'>Error Gates</a>....<a href='logout.php'>Logout</a><br><br>";
echo"<br><br><br>";
}
else
{
echo"<br><a href='logout.php'>Logout</a><br><br><br>";
}
echo'<div align="center"><font size="-1">';
echo"Gates From $name<br><br><br><br>";
echo"<TABLE>
      <TR background='images/list_background_2.png'>
      <TH><font size='-1'>Gate Name &nbsp &nbsp
      <TH><font size='-1'>Sim &nbsp &nbsp
      <TH><font size='-1'>Typ/Version &nbsp
      <TR>";
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY name";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[owner] == $name)
{
$kan = base64_encode($line[channel]);
echo '<br><br>
      <tc>
      <TR background="images/list_background_2.png">';
echo" <TH><form action='remote_action.php' method='get'>
      <INPUT TYPE='HIDDEN' NAME='one' VALUE='$kan'>
      <INPUT TYPE='HIDDEN' NAME='av' VALUE='$avkey'>
      <input type='submit' value='$line[name]'style='width:150px;height:30px;'>
      </input></form>&nbsp &nbsp
      <TH><font size='-1'>$line[sim]&nbsp&nbsp
      <TH><font size='-1'>$line[model]&nbsp&nbsp";
}
}
mysql_free_result($result);
mysql_close();
echo "</TABLE>";
if($god=="1")
{
//echo'<iframe src="http://caworks-sl.de/TGN/friends/web.php" frameborder="0" marginwidth="0" marginheight="0" width="Breite" height="H�he" scrolling="no"></iframe>';
}
?>
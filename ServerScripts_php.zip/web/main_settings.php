<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$newModel = $_GET['newModel'];
$sound = $_GET['sound'];
$color = $_GET['color'];
$channel = $_GET['channel'];
$typos = $_GET['typos'];
$close = $_GET['close'];
$set = $_GET['set'];
if($set != "")
{
echo"Saved data for $set: Sound:$sound Color:$color Channel:$channel typos:$typos Close:$close<br><br>";
select_db("stargate_t");
$query = "SELECT * FROM settings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[gatetyp] == $set)
{
$aendern = "UPDATE settings Set
sound = '$sound',
color = '$color',
channel = '$channel',
typos = '$typos',
close = '$close'
WHERE gatetyp = '$set'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
if($newModel != "New Model" && $newModel != "")
{
select_db("stargate_t");
mysql_query("INSERT INTO settings(id,gatetyp,sound,color,channel,typos,close)VALUES(NULL, '$newModel', 'empty', 'empty', 'empty', 'empty', 'empty')");
mysql_close();
}
echo"Main settings for Gates <br> <br>";
echo"<FORM METHOD='GET' ACTION='main_settings.php'>";
echo"<INPUT name='newModel' type='text' size='30' maxlength='30' value='New Model'><INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM>";
select_db("stargate_t");
$query = "SELECT * FROM settings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
echo"<FORM METHOD='GET' ACTION='main_settings.php'>";
echo "$line[gatetyp]<br><br>Sound:<INPUT name='sound' type='text' size='40' maxlength='40' value='$line[sound]'> Color:<INPUT name='color' type='text' size='27' maxlength='27' value='$line[color]'> Channel:<INPUT name='channel' type='text' size='15' maxlength='15' value='$line[channel]'> typos:<INPUT name='typos' type='text' size='1' maxlength='1' value='$line[typos]'> SoundClose:<INPUT name='close' type='text' size='40' maxlength='40' value='$line[close]'><INPUT TYPE='HIDDEN' NAME='set' VALUE='$line[gatetyp]'>-<INPUT TYPE ='SUBMIT' VALUE='Save'></INPUT></FORM><br><br><br>";
}
mysql_free_result($result);
mysql_close();
?>
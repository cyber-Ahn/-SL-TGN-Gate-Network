
<div align="center"><font size="-1"><font color="#000000">
<body link="#000000" vlink="#000000" text="#000000">
Stargatelist
<a href="ban.php">Banlist</a><br>
<a href="owner_del.php">Owner Delete</a>
<?php
include ("../liberay/lib.php");
$mailtext = "empty";
$entries = 10;
$site = $_GET['page'];
$chan = $_GET['channel'];
$send = $_GET['datas'];
if($site == "")
{
$site = "0";
}
$out = $site / $entries;
$out = $out + 1;
echo"<a href='logout.php'>....Logout</a>";
echo"<br>PAGE $out<br>";

$spal = $_GET['colu'];
$op1 = "Name";
$op2 = "Sim";
$op3 = "Owner";
if($spal == "")
{
$spal = "rati DESC";
}
echo"<FORM METHOD='GET' ACTION='gate_list_member.php'>
<SELECT NAME='colu' SIZE=1  VALUE='$spal'>
<OPTION>$op1
<OPTION>$op2
<OPTION>$op3
</select>";
echo "<INPUT TYPE ='SUBMIT' VALUE='ORDER'></FORM>";

echo "<br><br>";
echo"<TABLE>
<TR><TH><font size='-1'><font color='#000000'>Gate Name &nbsp
    <TH><font size='-1'><font color='#000000'>Sim &nbsp
    <TH><font size='-1'><font color='#000000'>Typ/Version &nbsp
    <TH><font size='-1'><font color='#000000'>Owner &nbsp";
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY $spal LIMIT $site,$entries";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$expc = explode("|",$line[datas]);
$address = $expc[0] ."<br>".$expc[1];
$rating = $line[rati];
echo "<br><br>
      <tc>
      <TR><TH><font size='-1'><a href=\"gate_data.php?one=".base64_encode($line[channel])."\">$line[name]&nbsp</a><br>
          <TH><font size='-1'><font color='#000000'>$line[sim]&nbsp&nbsp
	  	  <TH><font size='-1'><font color='#000000'>$line[model]&nbsp&nbsp
          <TH><font size='-1'><font color='#000000'>$line[owner]&nbsp
          <TH><font size='-1'><font color='#000000'>$address&nbsp
          <TH><font size='-1'><a href=\"dele.php?one=".base64_encode($line[channel])."&tow=".base64_encode($line[name])."\"><img border='0' src='images/off.png' width='15' height='15' alt='delete' ></a>&nbsp
          <TH><font size='-1'><a href=\"delete.php?one=".base64_encode($line[channel])."&tow=".base64_encode($line[name])."\"><img border='0' src='images/delete.png' width='15' height='15' alt='delete' ></a>&nbsp
          <TH><font size='-1'><a href=\"restart.php?one=".base64_encode($line[channel])."&tow=".base64_encode($line[name])."\"><img border='0' src='images/restart.png' width='15' height='15' alt='restart' ></a><br>
          <TH><form action='gate_list_member.php' method='get'><INPUT TYPE='HIDDEN' NAME='colu' VALUE='$spal'><INPUT TYPE='HIDDEN' NAME='page' VALUE='$site'><INPUT TYPE='HIDDEN' NAME='channel' VALUE='$line[smail]'><input color&#58;#000000;' type='text' size='5' maxlength='5' value='$line[rati]' name='datas'></input><input type='submit' value='SET'></input></form>
          ";
}
mysql_free_result($result);
mysql_close();
echo "</TABLE>";
echo"<div align='center'><font size='-1'>";


$ar = $site + $entries;
if($site == 0)
{
$arb = 0;
}
else
{
$arb = $site - $entries;
}
if($chan != "")
{
echo"$chan.......$send<br>";
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY $spal LIMIT $site,$entries";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]==$chan)
{
$aendern = "UPDATE gates Set
rati = '$send'
WHERE smail = '$chan'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
echo"<font size='-1'><a href=\"gate_list_member.php?page=".$arb."&colu=".$spal."\"><img border='0' src='images/arrow-left.png' width='15' height='15' alt='back' ></a> ";
echo"<font size='-1'><a href=\"gate_list_member.php?page=".$ar."&colu=".$spal."\"><img border='0' src='images/arrow-right.png' width='15' height='15' alt='next' ></a><br>";
?>
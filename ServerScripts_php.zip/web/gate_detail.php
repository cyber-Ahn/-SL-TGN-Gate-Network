<link rel=stylesheet href="../liberay/style.css" type="text/css">
<?php
include("../liberay/lib.php");
$pixe = "50";
$channel =  base64_decode($_GET['one']);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[channel] == $channel)
{
$nwid = $line[nwid];
$name = $line[name];
$sim = $line[sim];
$kordi = $line[kordi];
$owner = $line[owner];
$datas = $line[datas];
$gatestat = $line[gatestatus];
$imageurl = $line[imagesurl];
$imageurl_cach = $imageurl;
$ver = $line[model];
$randial = $line[randial];
$pro = $line[products];
$age = "";
$dbtime = $line[gateage];
$probb = $line[prob];
$exprob = explode("|",$probb);
$probb = $exprob[5];
$simdata = $line[displowner];
$load_data = $line[imageowner];
if(eregi(strtolower("Page Not Found"),strtolower($load_data))||$load_data == "")
{
$load_data = "images/empty_profil.png";
}
if($dbtime != "")
{
$cach = explode(" ",getdiffdate(unixtotime($dbtime),unixtotime(time())));
if($cach[0]!="0month")
{
$age = $age.$cach[0]." ";
}
if($cach[1]!="0week")
{
$age = $age.$cach[1]." ";
}
if($cach[2]!="0day")
{
$age = $age.$cach[2]." ";
}
if($cach[3]!="0hour")
{
$age = $age.$cach[3]." ";
}
if($cach[4]!="0min")
{
$age = $age.$cach[4]." ";
}
if($age != "")
{
$age = "Age:".$age;
}
}
}
}
mysql_free_result($result);
mysql_close();
$uuid = "Not Found!";
select_db("slmap");
$query = "SELECT * FROM sldb_data";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[field]==$sim)
{
$uuid = $line[value];
}
}
mysql_free_result($result);
mysql_close();
$imurl = "http://secondlife.com/app/image/$uuid/1";
echo "<div style='position:absolute; top:200px; left:0'><img src=$imurl width='125' height='125' alt='simimage'><br>Sim Image</div>";
echo "<div style='position:absolute; top:350px; left:0'><img src=$load_data width='125' height='125' alt='userimage'><br>User Image</div>";
$expi = explode("!",$imageurl);
$imageurl = $expi[0];
$ins = 0;
$ins = substr_count($imageurl, '-');
if($ins == 4)
{
$imageurl = "http://secondlife.com/app/image/$imageurl/1";
}
if($randial == "1")
{
$randial = "On";
}
elseif($randial == "0")
{
$randial = "Off";
}
elseif($randial == "")
{
$randial = "---";
}
$exp = explode("|",$datas);
$expb = explode("|",$gatestat);
if($exp[2] == "1")
{
$typ = "Milkyway";
}
elseif($exp[2] == "2")
{
$typ = "Pegasus";
}
elseif($exp[2] == "3")
{
$typ = "Universe";
}
if($expb[0] == "1")
{
$gate = "Online";
}
elseif($expb[0] == "0")
{
$gate = "Offline";
}
if($expb[1] == "1")
{
$sta = "Open";
}
elseif($expb[1] == "0")
{
$sta = "Idle";
}
if($expb[2] == "1")
{
$iri = "Closed";
}
elseif($expb[2] == "0")
{
$iri = "Open";
}
echo "<div style='position:absolute; top:50px; left:0'><img src=$imageurl width='125' height='125' alt='gateimage'><br>Gate Image</div>";
echo "<div align='center'><font size='+2'>";
echo "Stargate Information from $name";
echo "<br> on Simulatorversion: $simdata";
echo "<div align='center'><font size='-1'>";
$cach_proba = explode("/*",$probb);
$cach_probb = explode("*/",$probb);
echo"<br><textarea name='user_eingabe' cols='60' rows='7'>$cach_proba[0] $cach_probb[1]</textarea>";
echo "<font color='#000000'><br>Owner: $owner";
echo "<font color='#777a77'><br>Region: $sim";
echo "<font color='#000000'><br>Typ/Version: $ver";
echo "<font color='#777a77'><br>Network ID: $nwid";
echo "<font color='#000000'><br>$age";
echo "<font color='#777a77'><br>Random: $randial";
echo "<font color='#000000'><br>Network: $typ";
echo "<font color='#777a77'><br>Stargate is $gate&nbsp";
echo "<font color='#000000'><br>Gatestatus: $sta&nbsp";
echo "<font color='#777a77'><br>Iris: $iri&nbsp";
$dam = "Damage on";
if($exprob[7] == "0")
{
$dam = "No Damage";
}
$scr = "";
if($exprob[8] == "0")
{
$scr= "Scripts not allowed";
}
elseif($exprob[8] == "1")
{
$scr= "Scripts for Group allowed";
}
elseif($exprob[8] == "2")
{
$scr= "Scripts allowed";
}
echo "<font color='#000000'><br>Sim Data: FPS-$exprob[2] / Time-$exprob[3] / Avatar on Sim-$exprob[6] / $dam / $scr";
if($pro != "")
{
echo"<font color='#777a77'><br>Owner Use: $pro";
}
echo "<font color='#000000'><div align='center'><font size='+2'>";
if($typ == "Milkyway")
{
echo "<div align='center'><font size='+0'>";
$expm = explode(": ",$exp[0]);
$expmw = explode(", ",$expm[1]);
$xs = $expmw[0];
$xsa = $expmw[1];
$xsb = $expmw[2];
$xsc = $expmw[3];
$xsd = $expmw[4];
$xse = $expmw[5];
$expp = explode(": ",$exp[1]);
$exppw = explode(", ",$expp[1]);
$xy = $exppw[0];
$xya = $exppw[1];
$xyb = $exppw[2];
$xyc = $exppw[3];
$xyd = $exppw[4];
$xye = $exppw[5];
$xyf = $exppw[6];
$expu = explode(": ",$exp[3]);
$expuw = explode(", ",$expu[1]);
$xu = $expuw[0];
$xua = $expuw[1];
$xub = $expuw[2];
$xuc = $expuw[3];
$xud = $expuw[4];
$xue = $expuw[5];
$xuf = $expuw[6];
$xug = $expuw[7];
echo "<br><br><img src=images/mw/$xs.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsa.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xse.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#c02c30'><br>$xs &nbsp &nbsp &nbsp $xsa &nbsp &nbsp &nbsp $xsb &nbsp &nbsp &nbsp $xsc &nbsp &nbsp &nbsp $xsd &nbsp &nbsp &nbsp $xse";
echo "<br><img src=images/pw/$xy.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xya.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xye.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyf.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#4747e8'><br>$xy &nbsp &nbsp &nbsp $xya &nbsp &nbsp &nbsp $xyb &nbsp &nbsp &nbsp $xyc &nbsp &nbsp &nbsp $xyd &nbsp &nbsp &nbsp $xye &nbsp &nbsp &nbsp $xyf";
echo "<br><img src=images/uw/$xu.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xua.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xub.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuc.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xud.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xue.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuf.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xug.png width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#000000'><br>$xu &nbsp &nbsp &nbsp $xua &nbsp &nbsp &nbsp $xub &nbsp &nbsp &nbsp $xuc &nbsp &nbsp &nbsp $xud &nbsp &nbsp &nbsp $xue &nbsp &nbsp &nbsp $xuf &nbsp &nbsp &nbsp $xug";
}
elseif($typ == "Pegasus")
{
echo "<div align='center'><font size='+0'>";
$expm = explode(": ",$exp[0]);
$expmw = explode(", ",$expm[1]);
$xs = $expmw[0];
$xsa = $expmw[1];
$xsb = $expmw[2];
$xsc = $expmw[3];
$xsd = $expmw[4];
$xse = $expmw[5];
$xsf = $expmw[6];
$expp = explode(": ",$exp[1]);
$exppw = explode(", ",$expp[1]);
$xy = $exppw[0];
$xya = $exppw[1];
$xyb = $exppw[2];
$xyc = $exppw[3];
$xyd = $exppw[4];
$xye = $exppw[5];
$expu = explode(": ",$exp[3]);
$expuw = explode(", ",$expu[1]);
$xu = $expuw[0];
$xua = $expuw[1];
$xub = $expuw[2];
$xuc = $expuw[3];
$xud = $expuw[4];
$xue = $expuw[5];
$xuf = $expuw[6];
$xug = $expuw[7];
echo "<br><img src=images/mw/$xs.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsa.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xse.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsf.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#c02c30'><br>$xs &nbsp &nbsp &nbsp $xsa &nbsp &nbsp &nbsp $xsb &nbsp &nbsp &nbsp $xsc &nbsp &nbsp &nbsp $xsd &nbsp &nbsp &nbsp $xse &nbsp &nbsp &nbsp $xsf";
echo "<br><br><img src=images/pw/$xy.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xya.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xye.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#4747e8'><br>$xy &nbsp &nbsp &nbsp $xya &nbsp &nbsp &nbsp $xyb &nbsp &nbsp &nbsp $xyc &nbsp &nbsp &nbsp $xyd &nbsp &nbsp &nbsp $xye";
echo "<br><img src=images/uw/$xu.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xua.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xub.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuc.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xud.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xue.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuf.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xug.png width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#000000'><br>$xu &nbsp &nbsp &nbsp $xua &nbsp &nbsp &nbsp $xub &nbsp &nbsp &nbsp $xuc &nbsp &nbsp &nbsp $xud &nbsp &nbsp &nbsp $xue &nbsp &nbsp &nbsp $xuf &nbsp &nbsp &nbsp $xug";
}
elseif($typ == "Universe")
{
echo "<div align='center'><font size='+0'>";
$expm = explode(": ",$exp[0]);
$expmw = explode(", ",$expm[1]);
$xs = $expmw[0];
$xsa = $expmw[1];
$xsb = $expmw[2];
$xsc = $expmw[3];
$xsd = $expmw[4];
$xse = $expmw[5];
$xsf = $expmw[6];
$xsg = $expmw[7];
$expp = explode(": ",$exp[1]);
$exppw = explode(", ",$expp[1]);
$xy = $exppw[0];
$xya = $exppw[1];
$xyb = $exppw[2];
$xyc = $exppw[3];
$xyd = $exppw[4];
$xye = $exppw[5];
$xyf = $exppw[6];
$expu = explode(": ",$exp[3]);
$expuw = explode(", ",$expu[1]);
$xu = $expuw[0];
$xua = $expuw[1];
$xub = $expuw[2];
$xuc = $expuw[3];
$xud = $expuw[4];
$xue = $expuw[5];
echo "<br><img src=images/mw/$xs.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsa.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xse.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsf.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/mw/$xsg.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#c02c30'><br>$xs &nbsp &nbsp &nbsp $xsa &nbsp &nbsp &nbsp $xsb &nbsp &nbsp &nbsp $xsc &nbsp &nbsp &nbsp $xsd &nbsp &nbsp &nbsp $xse &nbsp &nbsp &nbsp $xsf &nbsp &nbsp &nbsp $xsg";
echo "<br><br><img src=images/pw/$xy.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xya.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyb.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyc.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyd.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xye.jpg width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/pw/$xyf.jpg width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#4747e8'><br>$xy &nbsp &nbsp &nbsp $xya &nbsp &nbsp &nbsp $xyb &nbsp &nbsp &nbsp $xyc &nbsp &nbsp &nbsp $xyd &nbsp &nbsp &nbsp $xye &nbsp &nbsp &nbsp $xyf";
echo "<br><img src=images/uw/$xu.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xua.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xub.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xuc.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xud.png width='$pixe' height='$pixe' alt='glyph 1'>&nbsp<img src=images/uw/$xue.png width='$pixe' height='$pixe' alt='glyph 1'>";
echo "<font color='#000000'><br>$xu &nbsp &nbsp &nbsp $xua &nbsp &nbsp &nbsp $xub &nbsp &nbsp &nbsp $xuc &nbsp &nbsp &nbsp $xud &nbsp &nbsp &nbsp $xue";
}
echo "<div align='center'><font size='-1'>";
echo "<br><br>Last 20 Connections<br>";
$exp_imgA = explode("!",$imageurl_cach);
$exp_imgB = explode("|",$exp_imgA[1]);
$count_img = count($exp_imgB);
for($i="0";$i<=($count_img-2);$i++)
{
$exp_cont = explode("#",$exp_imgB[$i]);
$from_gate = $exp_cont[0];
$to_gate = $exp_cont[1];
$time_start = $exp_cont[3];
$time_end = $exp_cont[2];
$tim = $time_start - $time_end;
$timeAt = unixtotime($time_start);
$nxx = $i + 1;
echo"$nxx.$from_gate to $to_gate for $tim seconds at $timeAt<br>";
}
?>
<br><br>
<br><a href="gate_list.php">BACK</a><br><br><br><br>
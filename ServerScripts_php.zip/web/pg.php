<link rel=stylesheet href="../liberay/style.css" type="text/css">
<div align="center"><font size="-1">
PG List
<?php
include("../liberay/lib.php");
echo "<br><br><br><br><br>";
echo"<TABLE>
<TR>
	<TH><font size='-1'>ID &nbsp
	<TH><font size='-1'>KEY &nbsp
    <TH><font size='-1'>STAT &nbsp";
select_db("stargate_t");
$query = "SELECT * FROM pg ORDER BY id";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
echo"     <TR>
		  <TH><font size='-1'>$line[id]&nbsp&nbsp
	  	  <TH><font size='-1'>$line[kana]&nbsp&nbsp
          <TH><font size='-1'>$line[stat]";
}
mysql_free_result($result);
mysql_close();
echo "</TABLE>";
echo"<div align='center'><font size='-1'>";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
$total = mysql_num_rows($result);
mysql_free_result($result);
mysql_close();
echo"Gates: $total";
?>
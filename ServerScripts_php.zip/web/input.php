<div align="center"><font size="-1">
<?php
include("../liberay/lib.php");
$name = $_POST["v1"];
$reason = $_POST["v2"];
select_db("stargate_t");
$gatestatus = "empty";
mysql_query("INSERT INTO bann(id,name,reason)VALUES(NULL , '$name', '$reason')");
mysql_close();
echo"<META HTTP-EQUIV=REFRESH CONTENT='1; URL=ban.php'>";
?>
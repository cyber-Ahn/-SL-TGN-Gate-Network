<?php
// Gate
include ("liberay/lib.php");
select_db("stargate_t");
mysql_query("CREATE TABLE gates (
id INT( 255 ) NOT NULL auto_increment,
name VARCHAR( 200 ) NOT NULL ,
randial VARCHAR( 200 ) NOT NULL ,
sim VARCHAR( 200 ) NOT NULL ,
kordi VARCHAR( 150 ) NOT NULL,
owner VARCHAR( 150 ) NOT NULL,
datas VARCHAR( 1000 ) NOT NULL,
channel VARCHAR( 150 ) NOT NULL,
gatestatus VARCHAR( 500 ) NOT NULL,
imagesurl VARCHAR( 2000 ) NOT NULL,
model VARCHAR( 2000 ) NOT NULL,
ausf VARCHAR( 2000 ) NOT NULL,
prob VARCHAR( 2000 ) NOT NULL,
radkanal VARCHAR( 2000 ) NOT NULL,
rpsim VARCHAR( 2000 ) NOT NULL,
smail VARCHAR( 2000 ) NOT NULL,
rati INT( 200 ) NOT NULL,
displowner VARCHAR( 2000 ) NOT NULL,
products VARCHAR( 2000 ) NOT NULL,
nwid VARCHAR( 2000 ) NOT NULL,
gateage VARCHAR( 2000 ) NOT NULL,
pingc INT( 200 ) NOT NULL,
opent INT( 200 ) NOT NULL,
blacklist VARCHAR( 2000 ) NOT NULL,
imageowner VARCHAR( 2000 ) NOT NULL,
iristype VARCHAR( 200 ) NOT NULL,
simrati VARCHAR( 200 ) NOT NULL,
PRIMARY KEY (id) );");
mysql_close();
// Api User
select_db("stargate_t");
mysql_query("CREATE TABLE api_key (
id INT( 255 ) NOT NULL auto_increment,
datas VARCHAR( 200 ) NOT NULL ,
owner VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
// Ban User
select_db("stargate_t");
mysql_query("CREATE TABLE bann (
id INT( 255 ) NOT NULL auto_increment,
name VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
// Contacts
select_db("stargate_t");
mysql_query("CREATE TABLE contacts (
id INT( 255 ) NOT NULL auto_increment,
namefrom VARCHAR( 200 ) NOT NULL ,
nameto VARCHAR( 200 ) NOT NULL ,
timestart VARCHAR( 200 ) NOT NULL ,
timend VARCHAR( 2000 ) NOT NULL ,
data VARCHAR( 2000 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
// Opengate
select_db("stargate_t");
mysql_query("CREATE TABLE opengate (
id INT( 255 ) NOT NULL auto_increment,
owner VARCHAR( 200 ) NOT NULL ,
sim VARCHAR( 200 ) NOT NULL ,
kanal VARCHAR( 200 ) NOT NULL ,
posi VARCHAR( 200 ) NOT NULL ,
status VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
// Products
select_db("stargate_t");
mysql_query("CREATE TABLE product (
id INT( 255 ) NOT NULL auto_increment,
name VARCHAR( 200 ) NOT NULL ,
vers VARCHAR( 200 ) NOT NULL ,
kana VARCHAR( 150 ) NOT NULL ,
pass VARCHAR( 150 ) NOT NULL ,
dring VARCHAR( 300 ) NOT NULL ,
obkey VARCHAR( 300 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
// RP User
select_db("stargate_t");
mysql_query("CREATE TABLE tgnrp (
id INT( 255 ) NOT NULL auto_increment,
owner VARCHAR( 200 ) NOT NULL ,
data VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
//User
select_db("stargate_t");
mysql_query("CREATE TABLE api_key (
id INT( 255 ) NOT NULL auto_increment,
avkey VARCHAR( 200 ) NOT NULL ,
name VARCHAR( 200 ) NOT NULL ,
pass VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
//Settings
select_db("stargate_t");
mysql_query("CREATE TABLE settings (
id INT( 255 ) NOT NULL auto_increment,
gatetyp VARCHAR( 200 ) NOT NULL ,
sound VARCHAR( 200 ) NOT NULL ,
color VARCHAR( 200 ) NOT NULL ,
channel VARCHAR( 200 ) NOT NULL ,
typos VARCHAR( 200 ) NOT NULL ,
close VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
//Ani - Settings
select_db("stargate_t");
mysql_query("CREATE TABLE anisettings (
id INT( 255 ) NOT NULL auto_increment,
chev_num VARCHAR( 200 ) NOT NULL ,
pos VARCHAR( 200 ) NOT NULL ,
glyph_num VARCHAR( 200 ) NOT NULL ,
glyph_tex VARCHAR( 200 ) NOT NULL ,
version VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
select_db("stargate_t");
mysql_query("CREATE TABLE unisettings (
id INT( 255 ) NOT NULL auto_increment,
chev_num VARCHAR( 200 ) NOT NULL ,
pos VARCHAR( 200 ) NOT NULL ,
glyph_tex VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
// rec - data
select_db("stargate_t");
mysql_query("CREATE TABLE rec_stat (
id INT( 255 ) NOT NULL auto_increment,
user VARCHAR( 200 ) NOT NULL ,
gate VARCHAR( 200 ) NOT NULL ,
tim VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
echo "Installation compled";
?>
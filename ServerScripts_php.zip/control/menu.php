<?php
include("../liberay/lib.php");
$mainmenu = "Shield,Options,Delete,Website,API (pdf),Reset,Top Gates,Preload,Get ID,TGN HQ,Support";
$mainmenut = "Choose a Option:\nShield - Shield Menu\nOptions - Options Menu\nDelete -  Delete Gate Inworld and from Server\nWebsite - TGN Website\nAPI (pdf) - API & Manual Website\nReset - Reset and close your Gate\nTop Gates - Shows the Top Gates\nPreload - Rez a Preloader for faster Texture and Sound load\nGet Id - Shows you the ID from this Gate\nTGN HQ - dials Gate Network Home\nSupport - Opens the support page";
$delmenu = "Yes,No";
$delmenut = "Delete Stargate?";
$delmenub = "Explosion,Beam";
$delmenutb = "How will the stargate vanish?";
$othermenu = "Random,Get a Gate,Website,Group,Landmark,Reset,Rate,Top Gates,Get ID,TGN HQ,Support";
$othermenut = "Choose a Option:\nRandom - Dials random a Gate\nGet a Gate - Sends you the TGN Gate Box\nWebsite - TGN Website(here can you found teh MANUAL)\nGroup- Sends you the TGN Group\nLandmark - Sends you the Landmark from TGN HQ\nReset - Reset the Gate\nRate - Give this Gate a Ratingpoint\nTop Gate - Shows the Top Gates\nGet ID -  Shows you the ID from this Gate\nTGN HQ - dials Gate Network Home\nSupport - Opens the support page";
$shieldmenu = "Iris,Energie,Lower,Raise";
$shieldmenut = "Choose a Option:\nIris - Set Shield to Iris like SGC\nEnergie - Set Shield to Energie Shield like SGA\nLower - Lower Iris\nRaise - Raise Iris";
$optionsmenu = "set Name,Offline,Public,Image URL,ChevReset,Restart,Reset,Random>,RP SIM,Delete";
$optionsmenut ="Choose a Option:\nset Name - Give your Gate a Name\nOffline - Set Gate offline\nPublic Turn on/off Public chat\nImage URL - Give your Gate a Image(Flickr URL or SL UUID)\nChevReset - Reload Chevron settings\nRestart - Restart your Gate(reset all scripts)\nReset - Reset and close your Gate\nRandom - Turn on/off Random Dial from this Gate\nRP SIM - Turn on/off RP Mode";
$rpmenu = "RP on,RP off";
$rpmenut = "Choose a Option:\nRP on - Turns RP mode on\nRP off - Turns RP mode off";
$randommenu = "On,Off";
$randommenut = "Random:\nOn - Turn Random dial on\nOff - Turn Random dial off";
$dialmenu = "Probe,Shutdown,Cut Power,Reset";
$dialmenut = "Choose a Option:\nProbe - Give you Information from the other Side\nShotdown - Shotdown open Wormhole\nCut Power - Close Gate\nReset - Reset the Gate\nShield - Open the Shield menu";
$data = base64_decode($_GET["nval"]);
$expa = explode("|",$data);
$smail = $expa[4];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$owner = $line[owner];
$statx = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$statx);
$gatepower = $expst[0];
$gateidle = $expst[1];
if($expa[0] == "image")
{
if($expa[1]=="set")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
imagesurl = '$expa[3]'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo "Image UUID-URL set to:$expa[3]";
}
}
if($expa[0] == "name")
{
if($expa[1]=="set")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
name = '$expa[3]'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo "Gatename set to:$expa[3]";
}
}
elseif($expa[0] == "menu")
{
if($expa[1]=="main")
{
if($expa[5]==$owner&&$gatepower=="1")
{
$channel = mt_rand(3000, 99999);
if($gateidle == "0")
{
$out = base64_encode("set_dialog|$mainmenu|$mainmenut|$expa[2]|$channel");
}
else
{
$dialmenux = "$dialmenu,Shield";
$out = base64_encode("set_dialog|$dialmenux|$dialmenut|$expa[2]|$channel");
}
echo"$out";
}
elseif($expa[5]!=$owner&&$gatepower=="1")
{
$channel = mt_rand(3000, 99999);
if($gateidle == "0")
{
$out = base64_encode("set_dialog|$othermenu|$othermenut|$expa[2]|$channel");
}
else
{
$out = base64_encode("set_dialog|$dialmenu|$dialmenut|$expa[2]|$channel");
}
echo"$out";
}
elseif($expa[5]==$owner)
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|Online|Online - Set gate online*$gatepower|$expa[2]|$channel");
echo"$out";
}
else
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|Restart|\nFound a Error please click Restart \n and wait 30 seconds for downloading new firmware|$expa[2]|$channel");
echo"$out";
}
}
if($expa[1]=="button")
{
if($expa[3]=="Get ID")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$found = $line[nwid];
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("IM|Gate ID: $found|$expa[2]");
echo"$out";
}
elseif($expa[3]=="Reset")
{
$out = base64_encode("stop");
echo"$out";
}
elseif($expa[3]=="Probe")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$sendtocach = $line[imagesurl];
}
}
mysql_free_result($result);
mysql_close();
$exp_imgA = explode("!",$sendtocach);
$exp_imgB = explode("|",$exp_imgA[1]);
$num_img = (count($exp_imgB)-2);
$sendtocachB= $exp_imgB[$num_img];
$expsendto = explode("#",$sendtocachB);
$sendto = $expsendto[1];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name]== $sendto)
{
$pro = $line[prob];
}
}
mysql_free_result($result);
mysql_close();
$exppro = explode("|",$pro);
if($exppro[7] == "1")
{
$pcdam = "Yes";
}
else
{
$pcdam = "No";
}
if($exppro[8] == "2")
{
$pcscr = "Yes";
}
else
{
$pcscr = "No";
}
$proout = "Fps:$exppro[2] \n Time:$exppro[3] \n Sim:$exppro[4] \n Parcel Desc:$exppro[5] \n Avatar on Sim:$exppro[6] \n Parcel Damage:$pcdam  \n Parcel allow Scripts:$pcscr";
$out = "$proout";
echo"$out";
}
elseif($expa[3]=="Shutdown")
{
$out = base64_encode("stop");
echo"$out";
}
elseif($expa[3]=="Cut Power")
{
$out = base64_encode("stop");
echo"$out";
}
elseif($expa[3]=="Top Gates")
{
$found = "";
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY rati DESC LIMIT 0, 10";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$found = $found.$line[name]."\n";
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("IM|$found|$expa[2]");
echo"$out";
}
elseif($expa[3]=="Preload")
{
$out = base64_encode("REZ|GNT Preload|<0.0,0.0,4.0>|<0.0,0.0,0.0>|<0.0,0.0,0.0,1.0>|0");
echo"$out";
}
elseif($expa[3]=="Website")
{
$out = base64_encode("URL|$expa[2]|Website:|http://www.cyber.caworks-sl.de/TGN/");
echo"$out";
}
elseif($expa[3]=="Support")
{
$out = base64_encode("URL|$expa[2]|Website:|http://caworks-sl.de/TGN/app/ticket/");
echo"$out";
}
elseif($expa[3]=="TGN HQ")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$send = $line[radkanal];
$mod = $line[model];
}
}
mysql_free_result($result);
mysql_close();
include ("../dial/dial_search.php");
dial("/d caworks", $send, "2",$mod,$smail);
}
elseif($expa[3]=="API (pdf)")
{
$out = base64_encode("URL|$expa[2]|API (pdf):|http://caworks-sl.de/TGN/gate/web/api.pdf");
echo"$out";
}
elseif($expa[3]=="Delete")
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|$delmenu|$delmenut|$expa[2]|$channel");
echo"$out";
}
elseif($expa[3]=="No")
{
}
elseif($expa[3]=="Yes")
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|$delmenub|$delmenutb|$expa[2]|$channel");
echo"$out";
}
elseif($expa[3]=="Beam")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$sql = "DELETE FROM gates WHERE smail ='$smail' ";
$db_erg = mysql_query($sql)
    or die("Anfrage fehlgeschlagen: " . mysql_error());
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("end|beam");
echo"$out";
}
elseif($expa[3]=="Explosion")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$sql = "DELETE FROM gates WHERE smail ='$smail' ";
$db_erg = mysql_query($sql)
    or die("Anfrage fehlgeschlagen: " . mysql_error());
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("end|explosion");
echo"$out";
}
elseif($expa[3]=="Rate")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$rate = $line[rati];
}
}
mysql_free_result($result);
mysql_close();
$rate = $rate + 1;
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
rati = '$rate'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("IM|You give this Gate one point!|$expa[2]");
echo"$out";
}
elseif($expa[3]=="Group")
{
$out = base64_encode("IM|secondlife:///app/group/c5230688-bfc8-0de2-5a2a-b88bd2bb0881/about|$expa[2]");
echo"$out";
}
elseif($expa[3]=="Landmark")
{
$data_out = "dval=$expa[2]|Landmark&ival=6&cval=$smail";
$url = "http://caworks-sl.de/TGN/gate/update/update_gate.php";
$out = base64_encode("httpR|$url|$data_out");
echo"$out";
}
elseif($expa[3]=="Random")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$send = $line[radkanal];
$mod = $line[model];
}
}
mysql_free_result($result);
mysql_close();
include ("../dial/dial_search.php");
dial("/d random", $send, "2",$mod,$smail);
}
elseif($expa[3]=="Get a Gate")
{
$send = base64_encode("$expa[2]|Open Source Stargate Server");
$wert_send = base64_encode("6");
$gchan = base64_encode($smail);
$data_out = "?dval=$send&ival=$wert_send&cval=$gchan";
$url = "http://caworks-sl.de/TGN/gate/update/update_gate_b.php";
$out = base64_encode("httpR2|$url|$data_out");
echo"$out";
}
elseif($expa[3]=="Shield")
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|$shieldmenu|$shieldmenut|$expa[2]|$channel");
echo"$out";
}
elseif($expa[3]=="Iris")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
iristype = 'iris'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("form|iris");
echo"$out";
}
elseif($expa[3]=="Energie")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
iristype = 'shield'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("form|shield");
echo"$out";
}
elseif($expa[3]=="Raise")
{
$out = base64_encode("status|1");
echo"$out";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "$expst[0]|$expst[1]|1";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
elseif($expa[3]=="Lower")
{
$out = base64_encode("status|0");
echo"$out";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "$expst[0]|$expst[1]|0";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
elseif($expa[3]=="Options")
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|$optionsmenu|$optionsmenut|$expa[2]|$channel");
echo"$out";
}
elseif($expa[3]=="RP SIM")
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|$rpmenu|$rpmenut|$expa[2]|$channel");
echo"$out";
}
elseif($expa[3]=="RP on")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
rpsim = 'yes'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo "Set Gate to RP-Gate";
}
elseif($expa[3]=="RP off")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
rpsim = 'no'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo "Set Gate to no RP-Gate";
}
elseif($expa[3]=="Restart")
{
$out = base64_encode("Reset|Script");
echo"$out";
}
elseif($expa[3]=="Random>")
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|$randommenu|$randommenut|$expa[2]|$channel");
echo"$out";
}
elseif($expa[3]=="On")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
randial = '1'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo "Randomdial on";
}
elseif($expa[3]=="Off")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
randial = '0'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo "Randomdial off";
}
elseif($expa[3]=="Public")
{
$out = base64_encode("puplic|set");
echo"$out";
}
elseif($expa[3]=="Image URL")
{
$channel = mt_rand(100, 999);
$out = base64_encode("image|$channel|$expa[2]|Say Image UUID/URL on channel: /");
echo"$out";
}
elseif($expa[3]=="ChevReset")
{
$out = base64_encode("chev|laod");
echo"$out";
}
elseif($expa[3]=="set Name")
{
$channel = mt_rand(100, 999);
$out = base64_encode("setname|$channel|$expa[2]|Say Gatename on channel: /");
echo"$out";
}
elseif($expa[3]=="Offline")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
$send = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$data = base64_encode("api-status|offline");
send_http_sl("4",$data,$send);
$expst = explode("|",$stat);
$setst = "0|$expst[1]|$expst[2]";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("gatepw|0|Contact to powersouce lost");
echo"$out";
}
elseif($expa[3]=="Online")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
$send = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "1|$expst[1]|$expst[2]";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("gatepw|0|Contact to powersource established");
echo"$out";
$data = base64_encode("api-status|idle");
send_http_sl("4",$data,$send);
}
elseif($expa[3]=="Obj Desc")
{
$out = base64_encode("Obj|desc");
echo"$out";
}
elseif($expa[3]=="Obj Name")
{
$out = base64_encode("Obj|name");
echo"$out";
}
elseif($expa[3]=="Remove Scripts")
{
$out = base64_encode("remove|scripts|all");
echo"$out";
}
else
{
echo"No function for this Button: $expa[3]";
}
}
}
?>
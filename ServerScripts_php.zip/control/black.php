<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$cach = explode(":",$data);
$cach_data = explode("|",$cach[1]);
$command = $cach_data[0];
$smail = $cach_data[1];
$owner = $cach_data[2];
if($cach[0]=="add")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail&&$owner==$line[owner])
{
$set = $line[blacklist];
$set = $set.$command."|";
$aendern = "UPDATE gates Set
blacklist = '$set'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo"$command add to Blacklist";
}
if($cach[0]=="delete")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail&&$owner==$line[owner])
{
$set_del = $line[blacklist];
$del_cach = explode("|",$set_del);
$pos=array_search($command,$del_cach);
unset($del_cach[$pos]);
$len = count($del_cach);
for($i="0";$i<=($len-1);$i++)
{
if($del_cach[$i]!="")
{
$del_set = $del_set.$del_cach[$i]."|";
}
}
$aendern = "UPDATE gates Set
blacklist = '$del_set'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
echo"$command delete from Blacklist";
}
if($cach[0]=="show")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail&&$owner==$line[owner])
{
$out = $line[blacklist];
}
}
mysql_free_result($result);
mysql_close();
$cach_out = explode("|",$out);
$len = count($cach_out);
for($i="0";$i<=($len-2);$i++)
{
$outX = $outX.$cach_out[$i]."\n";
}
echo"Blacklist:\n$outX";
}
?>
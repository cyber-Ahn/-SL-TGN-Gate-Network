<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$expa = explode("#",$data);
$scr = $expa[0];
$var = $expa[1];
$sendkey = $expa[2];
$command = $expa[3];
$smail = $expa[4];
$owner = $expa[5];
$obowner = $expa[6];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$owdb = $line[owner];
$statx = $line[gatestatus];
$mod = $line[model];
$namx = $line[name];
}
}
mysql_free_result($result);
mysql_close();
$found_d = strpos($command, "/d");
$found_asg = strpos($command, "/asg");
if($found_d===false&&$found_asg===false)
{
if($command == "/stargate name")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$nam = $line[name];
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("IM|Name of Gate: $nam|$expa[2]");
echo"$out";
}
elseif($command =="/stargate raise")
{
if($owner == $owdb || $obowner == $owdb)
{
$out = base64_encode("status|1");
echo"$out";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "$expst[0]|$expst[1]|1";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
}
elseif($command =="/stargate lower")
{
if($owner == $owdb || $obowner == $owdb)
{
$out = base64_encode("status|0");
echo"$out";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "$expst[0]|$expst[1]|0";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
}
elseif($command =="/stargate version")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$mod = $line[model];
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("IM|Gateversion: $mod|$expa[2]");
echo"$out";
}
elseif($command =="/stargate shutdown")
{
$out = base64_encode("stop");
echo"$out";
}
elseif($command =="/stargate reset")
{
$out = base64_encode("stop");
echo"$out";
}
}
else
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$send = $line[radkanal];
$mod = $line[model];
}
}
mysql_free_result($result);
mysql_close();
include ("../dial/dial_search.php");
dial($command, $send, "2",$mod,$smail);
}
?>
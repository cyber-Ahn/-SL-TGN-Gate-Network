<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$expa = explode("#",$data);
$scr = $expa[0];
$var = $expa[1];
$sendkey = $expa[2];
$command = $expa[3];
$smail = $expa[4];
$owner = $expa[5];
$obowner = $expa[6];
$sendto = $expa[7];
$expchat = explode("|",$command);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$owdb = $line[owner];
$statx = $line[gatestatus];
$mod = $line[model];
$namx = $line[name];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$statx);
if($command == "stargate name")
{
$out = base64_encode("api|out|stargate name|$namx");
echo"$out";
}
elseif($expchat[0]=="get_menu_chat")
{
$id = $expchat[1];
$ds_menu = "menu|main|$expchat[1]|x|$expchat[2]|$expchat[3]";
include("menu2.php");
$ds_generate = get_menu_api($ds_menu);
echo"$ds_generate";
}
elseif($expchat[0]=="stargate probe")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $sendto)
{
$pro = $line[prob];
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("api|out|$pro");
echo"$out";
}
if($owner == $owdb || $obowner == $owdb || eregi("DHD",$owner) || eregi("Keyboard",$owner) || eregi("Tulamesh",$owner) || eregi("Laptop",$owner))
{
if($command == "online stargate"&&$expst[0] == "0")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
$send = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "1|$expst[1]|$expst[2]";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("gatepw|0|Contact to powersource established");
echo"$out";
$data = base64_encode("api-status|idle");
send_http_sl("4",$data,$send);
}
elseif($expst[0] == "1")
{
if($command == "stargate status")
{
$infst = "status|idle";
if($expst[1]=="1")
{
$infst = "status|open";
}
$out = base64_encode("api|out|$infst");
echo"$out";
}
elseif($command == "stargate version")
{
$out = base64_encode("api|out|stargate version|$mod");
echo"$out";
}
elseif($command == "stargate address")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$ado = $line[datas];
}
}
mysql_free_result($result);
mysql_close();
$ado_l = explode("|",$ado);
if($ado_l[2]=="1")
{
$out = base64_encode("api|out|stargate address|$ado_l[0]");
}
if($ado_l[2]=="2")
{
$out = base64_encode("api|out|stargate address|$ado_l[1]");
}
if($ado_l[2]=="3")
{
$out = base64_encode("api|out|stargate address|$ado_l[3]");
}
echo"$out";
}
elseif($command == "raise shield")
{
$out = base64_encode("status|1");
echo"$out";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "$expst[0]|$expst[1]|1";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
elseif($command == "lower shield")
{
$out = base64_encode("status|0");
echo"$out";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$setst = "$expst[0]|$expst[1]|0";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
elseif($command == "offline stargate")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
$send = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$data = base64_encode("api-status|offline");
send_http_sl("4",$data,$send);
$expst = explode("|",$stat);
$setst = "0|$expst[1]|$expst[2]";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$out = base64_encode("gatepw|0|Contact to powersouce lost");
echo"$out";
}
elseif($command == "reset stargate")
{
$out = base64_encode("stop");
echo"$out";
}
elseif($command == "shutdown wormhole")
{
$out = base64_encode("stop");
echo"$out";
}
elseif($command == "cut wormhole")
{
$out = base64_encode("stop");
echo"$out";
}
elseif($command == "restart stargate")
{
$out = base64_encode("Reset|Script");
echo"$out";
}
elseif($command == "public output"||$command == "public output|1"||$command == "public output|0")
{
$out = base64_encode("puplic|set");
echo"$out";
}
elseif($command == "test stargate outgoing")
{
include ("../dial/dial_test.php");
dial($smail,"outgoing");
}
elseif($command == "test stargate incoming")
{
include ("../dial/dial_test.php");
dial($smail,"incoming");
}
elseif(eregi("directdial",$command))
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$send = $line[radkanal];
$mod = $line[model];
}
}
mysql_free_result($result);
mysql_close();
$expdial = explode("|",$command);
include ("../dial/dial_search.php");
dial("/d $expdial[2]", $send, "2",$mod,$smail);
}
elseif($command == "stargate emp")
{
if($expst[1]=="1")
{
$out = base64_encode("api|out|emp pulse sent");
echo"$out";
}
}
elseif($command == "interference")
{
$out = base64_encode("interference");
echo"$out";
}
elseif($expchat[0]=="send chatter")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $sendto)
{
$chan = $line[radkanal];
$statto = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$stat);
$expstto = explode("|",$statto);
if($expst[1]=="1"&&$expstto[1]=="1")
{
$nam_out = $expchat[1];
if($nam_out == "_IDC")
{
$data = base64_encode("api-$nam_out|$expchat[2]");
}
else
{
$data = base64_encode("api-chatter|$nam_out|$expchat[2]");
}
send_http_sl("4",$data,$chan);
}
}
elseif($command == "listrandom|0")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
randial = '0'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
elseif($command == "listrandom|1")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$aendern = "UPDATE gates Set
randial = '1'
WHERE smail = '$smail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
elseif($expchat[0] == "dial")
{
include ("../dial/dial_glyph.php");
dialg($smail,$expchat[2]);
}
}
}
?>
<?php
function get_menu_api($ds_code)
{
$mainmenu = "Shield,Options,Delete,Website,API (pdf),Reset,Top Gates,Preload,Get ID,TGN HQ,Support";
$mainmenut = "Choose a Option:\nShield - Shield Menu\nOptions - Options Menu\nDelete -  Delete Gate Inworld and from Server\nWebsite - TGN Website\nAPI (pdf) - API & Manual Website\nReset - Reset and close your Gate\nTop Gates - Shows the Top Gates\nPreload - Rez a Preloader for faster Texture and Sound load\nGet Id - Shows you the ID from this Gate\nTGN HQ - dials Gate Network Home\nSupport - Opens the support page";
$othermenu = "Random,Get a Gate,Website,Group,Landmark,Reset,Rate,Top Gates,Get ID,TGN HQ,Support";
$othermenut = "Choose a Option:\nRandom - Dials random a Gate\nGet a Gate - Sends you the TGN Gate Box\nWebsite - TGN Website(here can you found teh MANUAL)\nGroup- Sends you the TGN Group\nLandmark - Sends you the Landmark from TGN HQ\nReset - Reset the Gate\nRate - Give this Gate a Ratingpoint\nTop Gate - Shows the Top Gates\nGet ID -  Shows you the ID from this Gate\nTGN HQ - dials Gate Network Home\nSupport - Opens the support page";
$dialmenu = "Probe,Shutdown,Cut Power,Reset";
$dialmenut = "Choose a Option:\nProbe - Give you Information from the other Side\nShotdown - Shotdown open Wormhole\nCut Power - Close Gate\nReset - Reset the Gate\nShield - Open the Shield menu";
$data = $ds_code;
$expa = explode("|",$data);
$smail = $expa[4];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$owner = $line[owner];
$statx = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expst = explode("|",$statx);
$gatepower = $expst[0];
$gateidle = $expst[1];
if($expa[0] == "menu")
{
if($expa[1]=="main")
{
if($expa[5]==$owner&&$gatepower=="1")
{
$channel = mt_rand(3000, 99999);
if($gateidle == "0")
{
$out = base64_encode("set_dialog|$mainmenu|$mainmenut|$expa[2]|$channel");
}
else
{
$dialmenux = "$dialmenu,Shield";
$out = base64_encode("set_dialog|$dialmenux|$dialmenut|$expa[2]|$channel");
}
return $out;
}
elseif($expa[5]!=$owner&&$gatepower=="1")
{
$channel = mt_rand(3000, 99999);
if($gateidle == "0")
{
$out = base64_encode("set_dialog|$othermenu|$othermenut|$expa[2]|$channel");
}
else
{
$out = base64_encode("set_dialog|$dialmenu|$dialmenut|$expa[2]|$channel");
}
return $out;
}
elseif($expa[5]==$owner)
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|Online|Online - Set gate online*$gatepower|$expa[2]|$channel");
return $out;
}
else
{
$channel = mt_rand(3000, 99999);
$out = base64_encode("set_dialog|Restart|\nFound a Error please click Restart \n and wait 30 seconds for downloading new firmware|$expa[2]|$channel");
return $out;
}
}
}
}
?>
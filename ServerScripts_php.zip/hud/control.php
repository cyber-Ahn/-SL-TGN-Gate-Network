<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$expa = explode("|",$data);
$mainmenu = "Random,Favorites,IRISopen,IRISclose,GateSearch,Interference,AutoTP,GateInfo,GDO,SearchGateData,Orlin Gate,Uninstall";
$mainmenut = "Random - dial a random Gate from DB\nFavorites - Load favorites from NC\nGateSearch - Search Gate on sim\nInterference - Inteference on Gate,\nAutoTP -  Activate AutoTp by walking in Gate\nGateInfo - Activate Gate Infos\nGDO - Activate GDO\nSearchGateData - Search all data from a Gate\nOrlin Gate - Rez a Orline Gate\nUninstall - Uninstall TGN Plugin";
if($expa[0]=="mainMenu")
{
$channel = mt_rand(3000, 99999);
$data_out = base64_encode("set_dialog|$mainmenu|$mainmenut|$expa[1]|$channel");
echo"$data_out";
}
else if($expa[0]=="textbox")
{
$dialvalue = $expa[2];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if(eregi(strtolower($dialvalue),strtolower($line[name]))||eregi(strtolower($dialvalue),strtolower($line[sim]))||eregi(strtolower($dialvalue),strtolower($line[nwid]))||eregi($dialvalue,$line[datas]))
{
$kord = explode("|",$line[kordi]);
$stat = explode("|",$line[gatestatus]);
$online = $stat[0];
$idle = $stat[1];
$Iris = $stat[2];
if($online == 1)
{
$online = "Online";
}
else
{
$online = "Offline";
}
if($idle == 0)
{
$idle = "IDLE";
}
else
{
$idle = "Open";
}
if($Iris == 1)
{
$Iris = "Close";
}
else
{
$Iris = "open";
}
$data = $line[datas];
$datac = explode("|",$data);
$dataF = "$line[name]:\nNetworkID - $line[nwid]\nOwner - $line[owner]\nRegion - $line[sim]\nPosition - <$kord[0]>\nTyp - $line[model]\nRP-Sim - $line[rpsim]\nSL Server - $line[displowner]\nGate is - $online\nGate is - $idle\nIris - $Iris\nAddress - $datac[0]\nAddress - $datac[1]\nAddress - $datac[3]";
}
}
mysql_free_result($result);
mysql_close();
$data_out = base64_encode("im|$expa[1]|Data from $dataF");
echo"$data_out";
}
else if($expa[0]=="ini")
{
$info = "<1,1,1>";
$gdo = "<1,1,1>";
$tp = "<1,1,1>";
if($expa[2]=="0")
{
$info = "<1,0,0>";
}
if($expa[3]=="0")
{
$gdo = "<1,0,0>";
}
if($expa[4]=="0")
{
$tp = "<1,0,0>";
}
$out = base64_encode("set#set_pos|90|<0,-0.24,0>#set_size|90|<0.1,0.24,0.01>#set_alpha|90|1.0|ALL_SIDES#set_texture|90|17a1b867-95af-6bec-d0bb-073306d12c92|ALL_SIDES
#set_pos|91|<-0.018,-0.32,-0.3>#set_size|91|<0.05,0.05,0.01>#set_alpha|91|1.0|ALL_SIDES#set_texture|91|1db78c72-b2a8-5c6a-4492-4d10c6270c02|ALL_SIDES
#set_pos|92|<-0.018,-0.17,-0.3>#set_size|92|<0.04,0.04,0.01>#set_alpha|92|1.0|ALL_SIDES#set_texture|92|ddc19bf5-ca1e-8ff6-c328-c11c4a30fa9e|ALL_SIDES
#set_pos|93|<-0.018,-0.245,-0.3>#set_size|93|<0.1,0.035,0.01>#set_alpha|93|1.0|ALL_SIDES#set_texture|93|86585195-dddf-6f5a-d818-fd7f0eaae282|ALL_SIDES
#set_color|90|<1,1,1>
#set_color|91|$info
#set_color|93|$gdo
#set_color|92|$tp
");
echo"$out";
}
else if($expa[0]=="button")
{
	if($expa[2]=="Uninstall")
	{
	$data_out = base64_encode("remove|fav.TGN,Orlin Gate,plg.TGN");
	echo"$data_out";
	}
	if($expa[2]=="Random")
	{
	$data_out = base64_encode("say|123|/d random");
	echo"$data_out";
	}
	if($expa[2]=="Favorites")
	{
	$data_out = base64_encode("load|nc");
	echo"$data_out";
	}
	if($expa[2]=="IRISclose")
	{
	$data_out = base64_encode("api|raise shield");
	echo"$data_out";
	}
	if($expa[2]=="IRISopen")
	{
	$data_out = base64_encode("api|lower shield");
	echo"$data_out";
	}
	if($expa[2]=="Interference")
	{
	$data_out = base64_encode("api|interference");
	echo"$data_out";
	}
	if($expa[2]=="GateSearch")
	{
	$data_out = base64_encode("gatesearch|$expa[1]");
	echo"$data_out";
	}
	if($expa[2]=="AutoTP")
	{
	$data_out = base64_encode("autotp|$expa[1]");
	echo"$data_out";	
	}
	if($expa[2]=="GateInfo")
	{
	$data_out = base64_encode("gateinfo|$expa[1]");
	echo"$data_out";	
	}
	if($expa[2]=="GDO")
	{
	$data_out = base64_encode("gdo|$expa[1]");
	echo"$data_out";	
	}
	if($expa[2]=="Orlin Gate")
	{
	$data_out = base64_encode("rez|Orlin Gate");
	echo"$data_out";	
	}
	if($expa[2]=="SearchGateData")
	{
	$channel = mt_rand(3000, 99999);
	$data_out = base64_encode("text_box|$expa[1]|$channel|Enter a gatename, sim or network ID");
	echo"$data_out";	
	}
}
?>
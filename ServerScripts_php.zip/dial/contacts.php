<?php 
function contact($fromGate,$togate)
{
$counter_num = 20;
$namFrom = $fromGate;
$namTo = $togate;
$time_start = time();
$time_end = $time_start + rand(30,90);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[radkanal] == $fromGate)
{
$namFrom = $line[name];
}
if($line[radkanal] == $togate)
{
$namTo = $line[name];
}
}
mysql_free_result($result);
mysql_close();
select_db("stargate_t");
mysql_query("INSERT INTO contacts(id,namefrom,nameto,timstart,timend,data)VALUES(NULL , '$namFrom', '$namTo', '$time_start', '$time_end', 'empty')");
mysql_close();
$delyis = "0";
select_db("stargate_t");
$query = "SELECT * FROM contacts";
$result = mysql_query($query);
$totalis = mysql_num_rows($result);
if($totalis >= $counter_num)
{
$delyis = "1";
}
mysql_free_result($result);
mysql_close();
$setInfo = "$namFrom#$namTo#$time_start#$time_end";
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[name]== $namFrom)
{	
$cach_img = $line[imagesurl];
$exp_imgA = explode("!",$cach_img);
$exp_imgB = explode("|",$exp_imgA[1]);
$num_img = (count($exp_imgB)-1);
if($num_img >= $counter_num)
{
$set_img = "$exp_imgA[0]!$exp_imgB[1]|";
for($i="2";$i<=($num_img-1);$i++)
{
$set_img = "$set_img$exp_imgB[$i]|";
}
}
else
{
$set_img = $cach_img;
}
$set_img = "$set_img$setInfo|";
$aendern = "UPDATE gates Set
imagesurl = '$set_img'
WHERE name = '$namFrom'"; 
$update = mysql_query($aendern);
}
if($line[name]== $namTo)
{
$cach_img = $line[imagesurl];
$set_img = "$cach_img$setInfo|";
$aendern = "UPDATE gates Set
imagesurl = '$set_img'
WHERE name = '$namTo'"; 
$update = mysql_query($aendern);
$cach_img = $line[imagesurl];
$exp_imgA = explode("!",$cach_img);
$exp_imgB = explode("|",$exp_imgA[1]);
$num_img = (count($exp_imgB)-1);
if($num_img >= $counter_num)
{
$set_img = "$exp_imgA[0]!$exp_imgB[1]|";
for($i="2";$i<=($num_img-1);$i++)
{
$set_img = "$set_img$exp_imgB[$i]|";
}
$aendern = "UPDATE gates Set
imagesurl = '$set_img'
WHERE name = '$namTo'"; 
$update = mysql_query($aendern);
}
}
}
mysql_free_result($result);
mysql_close();
if($delyis == "1")
{
select_db("stargate_t");
$query = "SELECT * FROM contacts ORDER BY id LIMIT 1";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
$delid = $line[id];
$sql = "DELETE FROM contacts WHERE id ='$delid' ";
$db_erg = mysql_query($sql)or die("Anfrage fehlgeschlagen: " . mysql_error());
}
mysql_free_result($result);
mysql_close();
}
}
?>
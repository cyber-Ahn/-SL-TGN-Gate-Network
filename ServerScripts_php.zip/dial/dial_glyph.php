<?php 
function dialg($smail,$glyph)
{
$sound = get_chev_sound_url($smail);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $smail)
{
$send = $line[radkanal];
$mod = $line[model];
}
}
mysql_free_result($result);
mysql_close();
$expa = explode(" ",$mod);
$model = $expa[0];
if($model == "Milkyway"||$model == "caworks")
{
$chev = "x";
$print = base64_encode("move|$chev|$glyph|$sound|locked");
send_http_sl("9",$print,$send);
}
elseif($model == "Pegasus")
{
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($chev == $line[chev_num])
{
$runner_p = $line[pos];
}
if($glyph == $line[glyph_num])
{
$glyph_tex = $line[glyph_tex];
}
}
mysql_free_result($result);
mysql_close();
$chev = "x";
$print = base64_encode("movep|$chev|$glyph|$sound|locked|$glyph_tex|$runner_p");
send_http_sl("9",$print,$send);
}
elseif($model == "Universe")
{
select_db("stargate_t");
$query = "SELECT * FROM unisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($glyph == $line[chev_num])
{
$print = base64_encode("moveuf|x|$glyph|$sound|encoded|$line[glyph_tex]|dsX|$line[pos]|1");
}
}
mysql_free_result($result);
mysql_close();
send_http_sl("9",$print,$send);
}
}
?>
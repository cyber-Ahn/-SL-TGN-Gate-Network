<?php
function incoming($send,$chan,$from,$numbers)
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($from == $line[radkanal])
{
$sim = $line[sim];
$kord = $line[kordi];
$own = $line[owner];
$nam = $line[name];
$addi = $line[datas];
$otherchan = $line[smail];
}
}
$exp_add = explode("|",$addi);
$add = explode(": ",$exp_add[0]);
mysql_free_result($result);
mysql_close();
$korda = explode("|",$kord);
$data = base64_encode("api-incoming wormhole|$sim|<$korda[0]>|$own|$nam|$nam|$add[1]|NULL");
send_http_sl("4",$data,$send);
$data = base64_encode("api-status|incoming");
send_http_sl("4",$data,$send);
$sound = get_chev_sound_url($chan);
$exp_chan = explode("|",$sound);
for($i="1";$i<=$numbers;$i++)
{
$print = base64_encode("chev|$i|on|$sound|encoded");
send_http_sl("1",$print,$send);
usleep(250000);
}
$print = base64_encode("chev|7|on|$sound|");
send_http_sl("1",$print,$send);
$print = base64_encode("chev|8|on|$sound|");
send_http_sl("1",$print,$send);
$print = base64_encode("chev|0|on|$sound|engaged");
send_http_sl("1",$print,$send);
$print = base64_encode("whisper|-555557|dial success|c38c2f5e-eaeb-0221-d063-ebca2a5c2d29");
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[radkanal] == $send)
{
$timeopen = time();
$stat = $line[gatestatus];
$expst = explode("|",$stat);
$setst = "$expst[0]|1|$expst[2]";
$aendern = "UPDATE gates Set
gatestatus = '$setst',
opent = '$timeopen'
WHERE radkanal = '$send'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
send_http_sl("3",$print,$send);
$data = base64_encode("api-stargate open");
send_http_sl("4",$data,$send);
$data = base64_encode("api-chevron all engaged");
send_http_sl("4",$data,$send);
$data = base64_encode("api-status|incoming");
send_http_sl("4",$data,$send);
$data = base64_encode("api-incoming wormhole|$sim|<$korda[0]>|$own|$nam|$nam|$add[1]|NULL");
send_http_sl("4",$data,$send);
$data = base64_encode("irisstat|$otherchan");
send_http_sl("6",$data,$send);
$cachadd = explode("|",$addi);
$cachaddb = explode(": ",$cachadd[0]);
$add = $cachaddb[1];
$data = base64_encode("say-Incoming wormhole from $sim");
send_http_sl("4",$data,$send);
$data = base64_encode("api-radio|1");
send_http_sl("4",$data,$send);
$print = base64_encode("whisper|-555556|irisclosed");
send_http_sl("3",$print,$send);
$data = base64_encode("api-rp|sgrp|connecting");
send_http_sl("4",$data,$send);
sleep(1);
$data = base64_encode("api-rp|sgrp|connected");
send_http_sl("4",$data,$send);
}
?>
<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$expy = explode("|",$data);
$send = $expy[1];
$dialvalue = $expy[2];
if($expy[0]=="search")
{
$teleportvalue = search_gate_data($dialvalue,$send);
$expa = explode("|",$teleportvalue);
$expb = explode("#",$teleportvalue);
$expc = explode("*",$expb[1]);
$expne = explode("|",$expc[1]);
$rp = $expa[0];
$search_channel = $expa[3];
$sim = $expa[2];
$typ = $expa[7];
$kord = $expa[4];
$own = $expa[1];
$nam = $expc[0];
$othersend = $expne[0];
$ifdatabase = $expne[1];
$network = "";
$adi = "";
$len = "";
$dialvalue = $nam;
if($typ == 1)
{
$network = "milkyway";
$adi = $expa[5];
}
if($typ == 2)
{
$network = "pegasus";
$adi = $expa[6];
}
if($typ == 3)
{
$network = "universe";
$adi = $expa[8];
}
$expd = explode(": ",$adi);
$adi = $expd[1];
$expe = explode(", ",$adi);
$len = count($expe);
$adib = "";
for($i="0";$i<=($len-1);$i++)
{
if($i=="0")
{
$adib = $expe[$i];
}
else
{
$adib = $adib.",".$expe[$i];
}
}
$rp_text = "No RP Gate";
if($rp != "nodial")
{
$rp_text = "Connection with a RP Gate. Enter at your own risk.";
$data = base64_encode("api-rpsim|connecting");
send_http_sl("4",$data,$send);
}
$data = base64_encode("say-$rp_text");
send_http_sl("4",$data,$send);
$data = base64_encode("say-Dial:$dialvalue");
send_http_sl("4",$data,$send);
$data = base64_encode("api-radio|1");
send_http_sl("4",$data,$send);
$data = base64_encode("api-status|dialing");
send_http_sl("4",$data,$send);
$data = base64_encode("api-stargate open");
send_http_sl("4",$data,$send);
$data = base64_encode("api-chevron all encoded");
send_http_sl("4",$data,$send);
$data = base64_encode("api-dial succeeded|$sim|<$kord>|$network|$nam|$sim|$own|140667223|<0.00000, 0.00000, 0.00000, 1.00000>");
send_http_sl("4",$data,$send);
$ifon = $expa[9];
$ifidle = $expa[10];
$ifiris = $expa[11];
$expir = explode("#",$ifiris);
$ifiris = $expir[0];
$print = base64_encode("whisper|-555557|d|$sim|$kord");
send_http_sl("3",$print,$send);
usleep(250000);
if($ifon == "1"&&$ifidle == "0")
{
$print = base64_encode("whisper|-555557|dial success|c38c2f5e-eaeb-0221-d063-ebca2a5c2d29");
send_http_sl("3",$print,$send);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[radkanal] == $send)
{
$stat = $line[gatestatus];
$expst = explode("|",$stat);
$setst = "$expst[0]|1|$expst[2]";
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE radkanal = '$send'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($search_channel == $line[channel])
{
$otherchan = $line[smail];
}
}
mysql_free_result($result);
mysql_close();
$fromgate = $send;
include("contacts.php");
contact($fromgate,$othersend);
include ("incoming.php");
incoming($othersend,$otherchan,$fromgate,$len);
$data = base64_encode("api-status|outgoing");
send_http_sl("4",$data,$send);
$data = base64_encode("irisstat|$otherchan");
send_http_sl("6",$data,$send);
$data = base64_encode("api-destination|$sim|<$kord>|<0.00000, 0.00000, 0.00000, 1.00000>");
send_http_sl("4",$data,$send);
$data = base64_encode("api-rp|sgrp|connecting");
send_http_sl("4",$data,$send);
sleep(1);
$data = base64_encode("api-rp|sgrp|connected");
send_http_sl("4",$data,$send);
}
else
{
$data = base64_encode("stop");
send_http_sl("5",$data,$send);
}
}
?>
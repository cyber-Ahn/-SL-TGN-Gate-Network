<?php
function get_gate_stat($from_stat)
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[radkanal] == $from_stat)
{
$check_gate_stat = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$exp_check_gate_stat = explode("|",$check_gate_stat);
return $exp_check_gate_stat[1];
}
?>
<?php
function dial($data, $send, $chan,$model,$kanal)
{
$exp = explode(" ",$data);
$length = count($exp);
$dialvalue = "";
for($i=1;$i<=($length-1);$i++)
{
if($i == 1)
{
$dialvalue = $exp[$i];
}
else
{
$dialvalue = $dialvalue . " " . $exp[$i];
}
}
$dialtyp = $exp[0];
$teleportvalue = search_gate_data($dialvalue,$send);
$expa = explode("|",$teleportvalue);
$expb = explode("#",$teleportvalue);
$expc = explode("*",$expb[1]);
$expne = explode("|",$expc[1]);
$rp = $expa[0];
$search_channel = $expa[3];
$sim = $expa[2];
$typ = $expa[7];
$kord = $expa[4];
$own = $expa[1];
$nam = $expc[0];
$othersend = $expne[0];
$ifdatabase = $expne[1];
$simtype = $expa[13];
$network = "";
$adi = "";
$len = "";
if($teleportvalue!="empty"&&$ifdatabase=="0")
{
if($typ == 1)
{
$network = "milkyway";
}
if($typ == 2)
{
$network = "pegasus";
}
if($typ == 3)
{
$network = "universe";
}
$exp_model = explode(" ",$model);
if($exp_model[0] == "Milkyway"||$exp_model[0] == "caworks"||$exp_model[0] == "Tollan"||$exp_model[0] == "Low")
{
$adi = $expa[5];
}
elseif($exp_model[0] == "Pegasus"||$exp_model[0] == "Iconian"||$exp_model[0] == "Tula")
{
$adi = $expa[6];
}
elseif($exp_model[0] == "Universe")
{
$adi = $expa[8];
}
$expd = explode(": ",$adi);
$adi = $expd[1];
$expe = explode(", ",$adi);
$len = count($expe);
$adib = "";
for($i="0";$i<=($len-1);$i++)
{
if($i=="0")
{
$adib = $expe[$i];
}
else
{
$adib = $adib.",".$expe[$i];
}
}
$rp_text = "Simtype:$simtype";
if($rp != "nodial")
{
$rp_text = $rp_text." Connection with a RP Gate. Enter at your own risk.";
$data = base64_encode("api-rpsim|connecting");
send_http_sl("4",$data,$send);
$data = base64_encode("say-$rp_text");
send_http_sl("4",$data,$send);
}
else
{
$data = base64_encode("say-$rp_text");
send_http_sl("4",$data,$send);
}
$data = base64_encode("say-Dial:$dialvalue");
send_http_sl("4",$data,$send);
$data = base64_encode("api-radio|1");
send_http_sl("4",$data,$send);
$data = base64_encode("api-dial lookup|successful|$adib|$typ|$sim|<$kord>|$network|$nam|$sim|$own|NULL");
send_http_sl("4",$data,$send);
$data = base64_encode("api-status|dialing");
send_http_sl("4",$data,$send);
include("dial_ani.php");
dial_start($dialtyp,$model,$kanal,$send,$len,$adib);
include("dial_check.php");
$dial_info = get_gate_stat($send);
if($dial_info==0)
{
$data = base64_encode("api-chevron all encoded");
send_http_sl("4",$data,$send);
$data = base64_encode("api-dial succeeded|$sim|<$kord>|$network|$nam|$sim|$own|140667223|<0.00000, 0.00000, 0.00000, 1.00000>");
send_http_sl("4",$data,$send);
$ifon = $expa[9];
$ifidle = $expa[10];
$ifiris = $expa[11];
$expir = explode("#",$ifiris);
$ifiris = $expir[0];
$print = base64_encode("whisper|-555557|d|$sim|$kord");
send_http_sl("3",$print,$send);
usleep(250000);
if($ifon == "1"&&$ifidle == "0")
{
$print = base64_encode("whisper|-555557|dial success|c38c2f5e-eaeb-0221-d063-ebca2a5c2d29");
send_http_sl("3",$print,$send);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[radkanal] == $send)
{
$stat = $line[gatestatus];
$expst = explode("|",$stat);
$setst = "$expst[0]|1|$expst[2]";
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE radkanal = '$send'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
$data = base64_encode("api-stargate open");
send_http_sl("4",$data,$send);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($search_channel == $line[channel])
{
$otherchan = $line[smail];
}
}
mysql_free_result($result);
mysql_close();
$fromgate = $send;
include("contacts.php");
contact($fromgate,$othersend);
include("incoming.php");
incoming($othersend,$otherchan,$fromgate,$len);
$data = base64_encode("api-status|outgoing");
send_http_sl("4",$data,$send);
$data = base64_encode("irisstat|$otherchan");
send_http_sl("6",$data,$send);
$data = base64_encode("api-destination|$sim|<$kord>|<0.00000, 0.00000, 0.00000, 1.00000>");
send_http_sl("4",$data,$send);
$data = base64_encode("api-rp|sgrp|connecting");
send_http_sl("4",$data,$send);
sleep(1);
$data = base64_encode("api-rp|sgrp|connected");
send_http_sl("4",$data,$send);
}
else
{
$data = base64_encode("stop");
send_http_sl("5",$data,$send);
}
}
else
{
//ends dial by incomming
}
}
elseif($ifdatabase=="1")
{
$data = base64_encode("say-Dial a Opengate:$dialvalue");
$sound = get_chev_sound_url($kanal);
send_http_sl("4",$data,$send);
$data = base64_encode("api-dial lookup|successful|$adib|$typ|$sim|<$kord>|$network|$nam|$sim|$own|NULL");
send_http_sl("4",$data,$send);
$data = base64_encode("api-status|dialing");
send_http_sl("4",$data,$send);
$print = base64_encode("chev|1|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|2|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|3|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|4|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|5|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|6|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|7|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|8|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|0|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$data = base64_encode("api-stargate open");
send_http_sl("4",$data,$send);
$data = base64_encode("api-chevron all encoded");
send_http_sl("4",$data,$send);
$data = base64_encode("api-dial succeeded|$sim|<$kord>|$network|$nam|$sim|$own|140667223|<0.00000, 0.00000, 0.00000, 1.00000>");
send_http_sl("4",$data,$send);
$print = base64_encode("whisper|-555557|d|$sim|$kord");
send_http_sl("3",$print,$send);
usleep(250000);
$print = base64_encode("whisper|-555557|dial success|c38c2f5e-eaeb-0221-d063-ebca2a5c2d29");
send_http_sl("3",$print,$send);
$data = base64_encode("api-status|outgoing");
send_http_sl("4",$data,$send);
$data = base64_encode("api-destination|$sim|<$kord>|<0.00000, 0.00000, 0.00000, 1.00000>");
send_http_sl("4",$data,$send);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[radkanal] == $send)
{
$stat = $line[gatestatus];
$expst = explode("|",$stat);
$setst = "$expst[0]|1|$expst[2]";
$aendern = "UPDATE gates Set
gatestatus = '$setst'
WHERE radkanal = '$send'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();

}
else
{
$data = base64_encode("stop");
send_http_sl("5",$data,$send);
$data = base64_encode("say-Gate not found ($dialvalue)");
send_http_sl("4",$data,$send);
}
}
?>
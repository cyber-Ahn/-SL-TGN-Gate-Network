<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$expa = explode("|",$data);
$out = "not found";
if($expa[0] == "askiris")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($expa[1] == $line[smail])
{
$cacha = $line[gatestatus];
}
}
mysql_free_result($result);
mysql_close();
$expb = explode("|",$cacha);
$out = base64_encode("irawns|$expb[2]");
echo"$out";
}
if($expa[0] == "closeother")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($expa[1] == $line[smail])
{
$cacha = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$data = base64_encode("gate_close");
send_http_sl("7",$data,$cacha);
}
if($expa[0] == "setmystat")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail] == $expa[1])
{
$stTime = '0';
$stat = $line[gatestatus];
$expst = explode("|",$stat);
$setst = "$expst[0]|0|$expst[2]";
$aendern = "UPDATE gates Set
gatestatus = '$setst',
opent = '$stTime'
WHERE smail = '$expa[1]'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
if($expa[0] == "api")
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($expa[1] == $line[smail])
{
$cacha = $line[radkanal];
}
}
mysql_free_result($result);
mysql_close();
$print = base64_encode("api-$expa[2]|$expa[3]|$expa[4]");
send_http_sl("4",$print,$cacha);
}
if($expa[0] == "probe")
{
$ssmail = $expa[9];
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[smail]== $ssmail)
{
$aendern = "UPDATE gates Set
prob = '$expa[0]|$expa[1]|$expa[2]|$expa[3]|$expa[4]|$expa[5]|$expa[6]|$expa[7]|$expa[8]'
WHERE smail = '$ssmail'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
}
?>
<?php
function dial_start($dialspeed,$model,$chan,$send,$numbers,$adi)
{
$expa = explode(" ",$model);
$model = $expa[0];
//check model
$mode = "fast";
if($dialspeed == "/d")
{
if($model == "Milkyway"||$model == "caworks")
{
$mode = "milkslow";
}
elseif($model == "Pegasus")
{
$mode = "pegslow";
}
elseif($model == "Universe")
{
$mode = "unislow";
}
}
$sound = get_chev_sound_url($chan);
//fast
if($mode == "fast")
{
if($model == "Universe")
{
$exp_gly = explode(",",$adi);
for($i="1";$i<=$numbers;$i++)
{
$i_b = $i -1;
$glyph = $exp_gly[$i_b];
select_db("stargate_t");
$query = "SELECT * FROM unisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($glyph == $line[chev_num])
{
$print = base64_encode("moveuf|$i|$glyph|$sound|encoded|$line[glyph_tex]|ds$i|$line[pos]|0");
}
}
mysql_free_result($result);
mysql_close();
send_http_sl("9",$print,$send);
sleep(2);
}
}
//iconian
elseif($model == "Iconian")
{
$print = base64_encode("chev|0|on|$sound|encoded");
send_http_sl("1",$print,$send);
}
else
{
for($i="1";$i<=$numbers;$i++)
{
$print = base64_encode("chev|$i|on|$sound|encoded");
send_http_sl("1",$print,$send);
if($model == "Milkyway")
{
$print = base64_encode("chev|0|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
$print = base64_encode("chev|0|off|$sound|");
send_http_sl("1",$print,$send);
}
sleep(1);
}
$print = base64_encode("chev|0|on|$sound|encoded");
send_http_sl("1",$print,$send);
$print = base64_encode("chev|7|on|$sound|");
send_http_sl("1",$print,$send);
$print = base64_encode("chev|8|on|$sound|");
send_http_sl("1",$print,$send);
usleep(500000);
}
}
//slow  milkyway
if($mode == "milkslow")
{
$exp_chev = explode(",",$adi);
$len_chev = count($exp_chev);
for($i="0";$i<=($len_chev-1);$i++)
{
$chev = $i+1;
$glyph = $exp_chev[$i];
$print = base64_encode("move|$chev|$glyph|$sound|locked");
send_http_sl("9",$print,$send);
sleep(1);
}
$print = base64_encode("move|10|0|$sound|locked");
send_http_sl("9",$print,$send);
$namber = 99;
for($i="0";$i<=$namber;$i++)
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($chan == $line[smail])
{
$info = "info:$line[ausf]x";
}
}
mysql_free_result($result);
mysql_close();
if($info == "info:readyx")
{
$namber = "1";
}
sleep(1);
}
}
//slow peg
if($mode == "pegslow")
{
$glyph_tex = "";
$runner_p = "";
$exp_chev = explode(",",$adi);
$len_chev = count($exp_chev);
for($i="0";$i<=($len_chev-1);$i++)
{
$chev = $i+1;
$glyph = $exp_chev[$i];
select_db("stargate_t");
$query = "SELECT * FROM anisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($chev == $line[chev_num])
{
$runner_p = $line[pos];
}
if($glyph == $line[glyph_num])
{
$glyph_tex = $line[glyph_tex];
}
}
mysql_free_result($result);
mysql_close();
$print = base64_encode("movep|$chev|$glyph|$sound|locked|$glyph_tex|$runner_p");
send_http_sl("9",$print,$send);
sleep(2);
}
$print = base64_encode("movep|10|0|$sound|locked");
send_http_sl("9",$print,$send);
$namber = 99;
for($i="0";$i<=$namber;$i++)
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($chan == $line[smail])
{
$info = "info:$line[ausf]x";
}
}
mysql_free_result($result);
mysql_close();
if($info == "info:readyx")
{
$namber = "1";
}
sleep(1);
}
}
//slow   uni
if($mode == "unislow")
{
$exp_gly = explode(",",$adi);
for($i="1";$i<=$numbers;$i++)
{
$i_b = $i -1;
$glyph = $exp_gly[$i_b];
select_db("stargate_t");
$query = "SELECT * FROM unisettings";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($glyph == $line[chev_num])
{
$print = base64_encode("moveuf|$i|$glyph|$sound|encoded|$line[glyph_tex]|ds$i|$line[pos]|1");
}
}
mysql_free_result($result);
mysql_close();
send_http_sl("9",$print,$send);
sleep(2);
}
$print = base64_encode("moveuf|10|0|$sound|locked");
send_http_sl("9",$print,$send);
$namber = 99;
for($i="0";$i<=$namber;$i++)
{
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($chan == $line[smail])
{
$info = "info:$line[ausf]x";
}
}
mysql_free_result($result);
mysql_close();
if($info == "info:readyx")
{
$namber = "1";
}
sleep(1);
}
}
}
?>
<?php
function dial($chan,$dailtyp)
{
if($dailtyp == "outgoing")
{
$sound = get_chev_sound_url($chan);
$exp_chan = explode("|",$sound);
$print = base64_encode("chev|1|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|2|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|3|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|4|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|5|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|6|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|7|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|8|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("chev|0|on|$sound|encoded");
send_http_sl("1",$print,$exp_chan[2]);
sleep(1);
$print = base64_encode("whisper|-555557|dial success|c38c2f5e-eaeb-0221-d063-ebca2a5c2d29");
send_http_sl("3",$print,$exp_chan[2]);
sleep(5);
$print = base64_encode("whisper|-555557|gate close|72633c45-b610-7356-dce5-b122931a78c9");
send_http_sl("3",$print,$exp_chan[2]);
$print = base64_encode("chev|1|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|2|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|3|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|4|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|5|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|6|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|7|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|8|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|0|off|$sound|clear");
send_http_sl("1",$print,$exp_chan[2]);
}
if($dailtyp == "incoming")
{
$sound = get_chev_sound_url($chan);
$exp_chan = explode("|",$sound);
$print = base64_encode("chev|1|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|2|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|3|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|4|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|5|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|6|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|7|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|8|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(500000);
$print = base64_encode("chev|0|on|$sound|engaged");
send_http_sl("1",$print,$exp_chan[2]);
usleep(250000);
$print = base64_encode("whisper|-555557|dial success|c38c2f5e-eaeb-0221-d063-ebca2a5c2d29");
send_http_sl("3",$print,$exp_chan[2]);
sleep(5);
$print = base64_encode("whisper|-555557|gate close|72633c45-b610-7356-dce5-b122931a78c9");
send_http_sl("3",$print,$exp_chan[2]);
$print = base64_encode("chev|1|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|2|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|3|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|4|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|5|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|6|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|7|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|8|off|$sound");
send_http_sl("1",$print,$exp_chan[2]);
$print = base64_encode("chev|0|off|$sound|clear");
send_http_sl("1",$print,$exp_chan[2]);
}
}
?>
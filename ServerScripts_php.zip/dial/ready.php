<?php
include("../liberay/lib.php");
$data = base64_decode($_GET["nval"]);
$exp = explode("|",$data);
select_db("stargate_t");
$query = "SELECT * FROM gates";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
if($line[radkanal] == $exp[0])
{
$aendern = "UPDATE gates Set
ausf = '$exp[1]'
WHERE radkanal = '$exp[0]'"; 
$update = mysql_query($aendern);
}
}
mysql_free_result($result);
mysql_close();
?>
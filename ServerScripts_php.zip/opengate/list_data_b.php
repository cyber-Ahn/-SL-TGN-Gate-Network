<?php
include ("../liberay/lib.php");
select_db("stargate_t");
$query = "SELECT * FROM gates ORDER BY name";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
echo"$line[name]<br>";
}
mysql_free_result($result);
mysql_close();
?>
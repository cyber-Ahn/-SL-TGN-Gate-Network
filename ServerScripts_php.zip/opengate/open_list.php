<body bgcolor="#000000">
<div align="center"><font size="-1"><font color="#FFFFF0">
<body link="#FFFFFF" vlink="#FFFFF text="#FFFFFF">
OPENGATE
<?php
include ("../liberay/lib.php");
echo "<br><br><br><br>";
echo"<TABLE>
<TR><TH><font size='-1'><font color='#e5dede'>Owner
    <TH><font size='-1'><font color='#e5dede'>Sim
    <TH><font size='-1'><font color='#e5dede'>Kanal
    <TH><font size='-1'><font color='#e5dede'>Position
    <TH><font size='-1'><font color='#e5dede'>Status";
select_db("stargate_t");
$query = "SELECT * FROM opengate ORDER BY owner";
$result = mysql_query($query);
while ($line = mysql_fetch_array($result))
{
echo "<br><br>
      <tc>
      <TR><TH><font size='-1'><font color='#FFFFF0'>$line[owner]
          <TH><font size='-1'><font color='#FFFFF0'>$line[sim]
	  	  <TH><font size='-1'><font color='#FFFFF0'>$line[kanal]
          <TH><font size='-1'><font color='#FFFFF0'>$line[posi]
          <TH><font size='-1'><font color='#FFFFF0'>$line[status]";
}
mysql_free_result($result);
mysql_close();
?>
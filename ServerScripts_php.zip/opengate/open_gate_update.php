<?php
include ("../liberay/lib.php"); 
header('Content-Type: text/html; charset=utf-8'); 
$xml_datei='http://ma8p.com/~opengate/xml.cgi';
select_db("stargate_t");
$table = "opengate";
$query = mysql_query ("drop table $table");
mysql_close();
select_db("stargate_t");
mysql_query("CREATE TABLE opengate (
id INT( 255 ) NOT NULL auto_increment,
owner VARCHAR( 200 ) NOT NULL ,
sim VARCHAR( 200 ) NOT NULL ,
kanal VARCHAR( 200 ) NOT NULL ,
posi VARCHAR( 200 ) NOT NULL ,
status VARCHAR( 200 ) NOT NULL ,
PRIMARY KEY (id) );");
mysql_close();
select_db("stargate_t");
$xml_object = simplexml_load_file($xml_datei); 
foreach($xml_object->gate as $key =>$value)
{
$exp = explode("(",$value->LOCAL_POSITION);
$expb = explode(")",$exp[1]);
$expc = explode(" (",$value->REGION);
$stat = "1";
$out = "$value->OWNER_NAME|$expc[0]|$value->OBJECT_KEY|$expb[0]|$stat";
$data = explode("|",$out);
mysql_query("INSERT INTO opengate(id,owner,sim,kanal,posi,status)VALUES(NULL , '$data[0]', '$data[1]', '$data[2]', '$data[3]', '$data[4]')");
}
mysql_close();
?> 